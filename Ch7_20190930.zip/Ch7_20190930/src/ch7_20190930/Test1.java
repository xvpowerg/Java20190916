/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190930;

/**
 *
 * @author xvpow
 */
public class Test1 {
    Test1(){
        this(10);
        System.out.println("Test1()");
    }
     Test1(float v1){
         this(v1,20);
        System.out.println("Test1(float v1)");
    }
    Test1(short v1){
         this(v1,30);
        System.out.println(" Test1(short v1)");
    }
    Test1(float f1,int v2){
        System.out.println("float f1 int:"+v2);
    }
    
}
