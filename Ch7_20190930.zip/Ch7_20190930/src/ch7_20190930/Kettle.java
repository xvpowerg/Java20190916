/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190930;

/**
 *
 * @author xvpow
 */
public class Kettle {
    //屬性
    //capcity 不可小100 大於2000    
    private int capacity;
    //封裝 Encapsulation
    private String color;
    String material;
    //預設建構子
    Kettle(){
       this(0,"未填入顏色" ,"未寫入材質");
    }
    //Constructor 建構子 或 建構式
    Kettle(int capacity,String color,String material){
        this.capacity = capacity;
        this.color = color;
        this.material = material;
    }
     //Constructor 可多載
    Kettle(int capacity,String color){
        //this()只能是第一個命令
        this(capacity,color,null);
        this.capacity = capacity;
        this.color = color;

    }
    
    public void setCapacity(int myCapcity){
        if (myCapcity > 2000 || myCapcity < 100){
            System.out.println("錯誤的容量!");
            return;
        }
        capacity = myCapcity;
    }
    
    public int getCapacity(){
        return capacity;
    }
    //寫入
    public void setColor(String myColor){
        if (  myColor == null){
            System.out.println("myColor不可為null");
            return;
        }
       if (myColor.length() > 10){
                  System.out.println("不可大於10");
        }
//        if (myColor!= null && 
//                myColor.length() > 10){
//                  System.out.println("不可大於10");
//        }
        //字串的長度也myColor.length() 不可大於10
        //如果為null時顯示訊息myColor不可為null
        color = myColor;
    }
    //讀取
    public String getColor(){
        return color;
    }
    
    void print(){
        System.out.println(capacity+":"+color+":"+material);
    }
    
}
