/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190930;

/**
 *
 * @author xvpow
 */
public class Ch7_1 {

    public static void main(String[] args) {
           Kettle k1 = new Kettle();
           //k1.capacity =  300;
           k1.setCapacity(300);
           //k1.color = "紅";
           k1.setColor(null);
           k1.material = "不鏽鋼";
           
           Kettle k2 = new Kettle();
           k2.setCapacity(500);
          // k2.capacity = 500;
          // k2.color = "黑";
          k2.setColor("黑");
           k2.material = "鋁";           
           k1.print();
           k2.print();
           
//           System.out.println(k1.capactiy);
//           System.out.println(k1.material);
//           System.out.println(k1.color);
//           System.out.println("=====================");
//          System.out.println(k2.capactiy);
//           System.out.println(k2.material);
//           System.out.println(k2.color);
           //capactiy  500
           //color 黑
           // material 鋁
        
    }
    
}
