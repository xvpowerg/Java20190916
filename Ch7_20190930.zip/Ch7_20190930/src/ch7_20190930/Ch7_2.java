/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190930;

/**
 *
 * @author xvpow
 */
public class Ch7_2 {

    public static void main(String[] args) {
      Kettle k3 = new Kettle(500,"藍","合金");
        k3.print();
       Kettle k4 = new Kettle(300,"藍");   
        k4.print();
    Kettle k5 = new Kettle();  
     k5.print();
    }
    
}
