/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191007;

/**
 *
 * @author xvpow
 */
public class Ch10_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //必考
       //方法複寫規則
       //1 讀取權限只能越來越開放 
         //開放順序
         //1 public 
         //2 protected
         //3 default         
       //2 private 不算複寫
       //3 default 在不同package不算複寫
       //4 回傳值如果是基本型態必須一模一樣
       //5 回傳值是非基本型態可以是一樣或子類型
       //6 方法名稱與傳入參數必須一樣
       //7 拋出例外可拋出一樣或子類型或不拋出        
        TestOverride1 to2 = new TestOverride2();
        to2.publicMethod();
        to2.protectedMethod();
        to2.defaultMethod();   
    }
    
     
    
}
