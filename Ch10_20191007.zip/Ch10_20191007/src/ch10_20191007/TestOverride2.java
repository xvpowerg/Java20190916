/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191007;
import ch10_20191007.exception.EditTextFileNotOpenException;
/**
 *
 * @author xvpow
 */
public class TestOverride2 extends TestOverride1{
    public void publicMethod(){
        System.out.println("TestOverride2 publicMethod");
    }
    //public
    protected void protectedMethod(){
        System.out.println("TestOverride2 protectedMethod");
    }
     //public 
     //protected
     void defaultMethod(){
        System.out.println("TestOverride2 defaultMethod");
    }
     //4 回傳值如果是基本型態必須一模一樣
     /*public float pluse(){
         return 10;
     }*/
    
  //5 回傳值是非基本型態可以是一樣或子類型
     public TestOverride2 copyObject(){
         return new TestOverride2();
     }
      //7 拋出例外可拋出一樣或子類型或不拋出        
     @Override
   public void testException()throws EditTextFileNotOpenException{
       
   }  
}
