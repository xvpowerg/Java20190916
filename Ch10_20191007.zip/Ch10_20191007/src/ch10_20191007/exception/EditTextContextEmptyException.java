/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191007.exception;

/**
 *
 * @author xvpow
 */
public class EditTextContextEmptyException extends RuntimeException{
    public EditTextContextEmptyException(){
        
    }
    public EditTextContextEmptyException(String msg){
        super(msg);
    }
}
