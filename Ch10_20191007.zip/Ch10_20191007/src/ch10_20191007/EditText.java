/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191007;
import ch10_20191007.exception.EditTextFileNotOpenException;
import ch10_20191007.exception.EditTextContextEmptyException;
public class EditText {
    private String tmpPath = "c:\\file.txt";   
    public void openFile(String path) throws EditTextFileNotOpenException{
        if (tmpPath.equals(path)){
            System.out.println("開啟檔案");
        }else{
           throw new EditTextFileNotOpenException("無法開啟:"+path);  
        }       
    }    
    public void writeFile(String value){
        if (value == null || value.trim().isEmpty()){
            throw new EditTextContextEmptyException("寫入內容為空白");
        }
        System.out.println("寫入成功!");
    }        
}
