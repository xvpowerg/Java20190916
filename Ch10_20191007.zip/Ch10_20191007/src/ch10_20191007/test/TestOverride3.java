package ch10_20191007.test;
import ch10_20191007.TestOverride1;
public class TestOverride3  extends TestOverride1{
    public void publicMethod(){
        System.out.println("TestOverride3 publicMethod");        
    }
    //我要檢查這個方法是否為正確的複寫
    @Override 
    protected void protectedMethod(){
         System.out.println("TestOverride3 protectedMethod");    
    }
    //@Override 
    void defaultMethod(){
        System.out.println("TestOverride3 defaultMethod");    
    }
   
    private void privateMethod(){
         System.out.println("TestOverride3 privateMethod");    
    }
}
