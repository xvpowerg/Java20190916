/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191007;
import ch10_20191007.exception.EditTextFileNotOpenException;
public class Ch10_1 {

 
    public static void main(String[] args) {
      EditText et = new EditText();
      try{
        et.openFile("c:\\file.txt");   
        et.writeFile(" ");
      }catch(EditTextFileNotOpenException ex){
          System.out.println(ex);
      }
       
        
    }
    
}
