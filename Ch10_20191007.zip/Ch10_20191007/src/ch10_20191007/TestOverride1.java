/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191007;

/**
 *
 * @author xvpow
 */
public class TestOverride1 {
    public void publicMethod(){
        System.out.println("TestOverride1 publicMethod!");
    }
    protected void protectedMethod(){
          System.out.println("TestOverride1 protectedMethod!");
    }
    void defaultMethod(){
         System.out.println("TestOverride1 defaultMethod!");
    }
    private void privateMethod(){
           System.out.println("TestOverride1 privateMethod!");
    }
    
    public int pluse(){
        return 10;
    }
    
    public TestOverride1 copyObject(){
        return new TestOverride1();
    }
    
    public void testException()throws Exception{
        
    }
}
