/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191101;
import java.util.function.Function;
/**
 *
 * @author shihhaochiu
 */
public class Test4<T> {
    public<E> T mapTo(E v,Function<E,T> function){
      return function.apply(v);
    } 
}
