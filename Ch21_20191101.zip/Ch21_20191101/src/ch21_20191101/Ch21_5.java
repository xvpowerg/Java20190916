/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191101;
import java.util.HashMap;
/**
 *
 * @author shihhaochiu
 */
public class Ch21_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap<Integer,String> locMap = new HashMap<>();
        locMap.put(1, "高雄");
        locMap.put(2, "台北");
        locMap.put(3, "台中");
        //假設1是高雄
        //假設2是台北
        //假設3是台中
      MyKey key = new MyKey("Ken",1);
      Test4<String> t4  = new Test4();
      String v =  t4.<Integer>mapTo(10, (i)->"value:"+i);
      System.out.println(v);
      
    Test4<String> t5  = new Test4();
    String locName = t5.<MyKey>mapTo(key,(k)->locMap.get(k.getLocation()));
    System.out.println(locName);
    }
    
}
