/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191101;
import java.util.stream.IntStream;
/**
 *
 * @author shihhaochiu
 */
public class Ch21_6 {

 
    public static void main(String[] args) {
        
        IntStream.range(1, 11).forEach(System.out::println);
        
        
    }
    
}
