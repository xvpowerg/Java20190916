/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191101;
import java.util.ArrayList;
/**
 *
 * @author shihhaochiu
 */
public class Ch21_4 {
    
    static void testList(ArrayList<Test1> list ){
        
    }
    
    //所有Test2的子類泛型的可當作此方法參數
    //? extends 這是唯讀
    static void testList2(ArrayList<? extends Test2> list){
        list.forEach(System.out::println);
        
        
    }
    
    //所有Test2的父類泛型的可當作此方法參數
    //list 能夠 add的是Test2的子類型
    static void testList3(ArrayList<? super Test2 > list){
         
         
         list.add(new Test3("Msg Test3"));
         list.add(new Test2("Msg Test2"));
            for (Object ob : list){
             System.out.println(ob);
         } 
    }
    
    public static void main(String[] args) {
        //使用泛型時右邊類型必須跟左邊一樣 或 <> 
       ArrayList<Test1> list = new ArrayList<>();      
        testList(list);
        list.add(new Test1());
        
         ArrayList<Test1> list2 = new ArrayList<>();
         //錯誤原因ArrayList<Test1> 的泛型是Test1 而傳入泛型是Test2
         
           testList(list2);    
           
        ArrayList<Test3> list3 = new ArrayList<>();   
        list3.add(new Test3("Test3_1"));
        list3.add(new Test3("Test3_2"));
         list3.add(new Test3("Test3_3"));
         
        ArrayList<Test2> list4 = new ArrayList<>(); 
        list4.add(new Test2("Test2_1"));
         list4.add(new Test2("Test2_2"));
          list4.add(new Test2("Test2_3"));
          
           testList2(list3);
           
           testList3(list);
           testList3(list4);
        
    }
    
}
