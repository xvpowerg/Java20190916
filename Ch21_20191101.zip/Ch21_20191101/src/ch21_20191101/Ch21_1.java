/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191101;
import java.util.Map;
import java.util.TreeMap;
import java.util.Set;
/**
 *
 * @author shihhaochiu
 */
public class Ch21_1 {

    public static void main(String[] args) {
        
        TreeMap<Integer,String> map = new TreeMap<>();
        map.put(10, "Ken");
        map.put(5, "Vivin");
        map.put(8, "Lindy");
        map.put(3, "Join");
        
       Set<Map.Entry<Integer,String>> set =  map.entrySet();
       set.forEach((entry)->{
           System.out.println(entry.getKey()+":"+entry.getValue());
       
       });
        
    }
    
}
