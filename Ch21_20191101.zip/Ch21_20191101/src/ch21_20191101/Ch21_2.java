/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191101;
import java.util.Comparator;
import java.util.TreeMap;
/**
 *
 * @author shihhaochiu
 */
public class Ch21_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//       TreeMap<MyKey,String> map2 = new  TreeMap<>((k1,k2)->{
//          
//          int cmp =   k1.getLocation() - k2.getLocation();
//           return  cmp ==0?k1.getName().compareTo(k2.getName()):cmp ;
//       });
 TreeMap<MyKey,String> map2 = new  TreeMap<>(Comparator.<MyKey,Integer>comparing(k->k.getLocation()).
         thenComparing(k->k.getName()));
        MyKey key1 = new MyKey("Ken",2);
        MyKey key2 = new MyKey("Vivin",1);
        MyKey key3 = new MyKey("Lindy",2);
        MyKey key4 = new MyKey("Join",3);
        MyKey key5 = new MyKey("Join",1);
        
        map2.put(key1, "A班");
        map2.put(key2, "B班");
        map2.put(key3, "A班");
        map2.put(key4, "C班");
        map2.put(key5, "D班");
        
        map2.forEach((k,v)->{System.out.println(k+":"+v);});
    }
    
}
