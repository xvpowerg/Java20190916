/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191101;
import java.util.ArrayList;
/**
 *
 * @author shihhaochiu
 */
public class Ch21_3 {

   
    public static void main(String[] args) {
         /* Algorithm<String> a1 = new Algorithm<>();
         String ans =  a1.calculation("A", "B", (v1,v2)->v1+v2);
         System.out.println(ans);
         
          Algorithm<Integer> a2 = new Algorithm<>();
         int ans2 =  a2.calculation(10, 20, (v1,v2)->v1+v2);
          System.out.println(ans2);*/
         
         ArrayList<String> list = new ArrayList<>();
         list.add("A");
         list.add("B");
         list.add("C");
         Foreach foreach = new Foreach<>();
         foreach.printAll(list);
         
    }
    
}
