/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191014;

/**
 *
 * @author xvpow
 */
/*
類別的介面的關係implements
implements 實作
*/
public class Airplane  implements Fly{
    public void flying(float speed){
        System.out.println("飛機~~飛行速度:"+speed);
    }
}
