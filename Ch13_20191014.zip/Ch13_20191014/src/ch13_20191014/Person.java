/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191014;

/**
 *
 * @author xvpow
 */
public abstract class Person {
    private String name;
    private int height;
    public Person(String name,int height){
        this.name = name;
        this.height = height;
    }
    public int getHeight(){
        return height;
    }
    public String getName(){
        return formatName(name);
    }
    private String formatName(String name){
          return "姓名:"+name;
    }
    //abstract提醒開發人員 繼承後你必須實際把此方法完成
    public abstract String voice();
    
    public String toString(){
        return this.getName()+":"+this.height+":"+this.voice();
    }
}
