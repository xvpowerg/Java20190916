/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191014;

public interface Fly {
    //介面基本的方法預設為 public abstract 的類型
    //除了public 或 不輸入都正確
      void flying(float speed);
}
