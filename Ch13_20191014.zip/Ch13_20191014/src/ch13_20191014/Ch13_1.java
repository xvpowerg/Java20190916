/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191014;

public class Ch13_1 {
    public static void main(String[] args) {
        //當類別為final就會無法被繼承
        //當方法為final就無法被複寫
        
        //抽象類別不可為final
        //抽象方法不可為final
        //抽象方法不可為private
        
        
       Person p1 = new Ken(175);
       System.out.println(p1);
        
        
    }
    
}
