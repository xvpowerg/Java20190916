/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191021;

/**
 *
 * @author xvpow
 */
public class Ch16_1 {
    
    //非靜態內部類
    public class MyInner{
        private String name;
        private int id;
        public MyInner(String name,int id){
            this.name = name;
            this.id = id;
        }
        
        public int getId(){
            return id;
        }
        public String getName(){
            return name;
        }
        public String toString(){
            return name+":"+id;
        }
    }
    
    public void testInner(){
         MyInner myInner = new MyInner("Join",200);   
    }
    //靜態內部類
   public static class  MyStaticInner {
        private float price;
        private String prodName;
        public MyStaticInner(float price,String prodName){
                this.price = price;
                this.prodName = prodName;
        }
        public boolean equals(Object obj){
            if (obj!= null && obj instanceof MyStaticInner == false){
                return false;
            }
            MyStaticInner si = (MyStaticInner)obj;
            return si.price == price && si.prodName.equals(this.prodName);
        }
   }
    //匿名內部類
    
    
    public static void main(String[] args) {
    
        Ch16_1 myObj = new Ch16_1();
       MyInner myInner =myObj.new  MyInner("Join",200);   
        System.out.println(myInner);
        
        MyStaticInner ms1 = new MyStaticInner(11.5f,"iPad");
        MyStaticInner ms2 = new MyStaticInner(11.5f,"iPad");
        System.out.println(ms1.equals(ms2));
    }
    
}
