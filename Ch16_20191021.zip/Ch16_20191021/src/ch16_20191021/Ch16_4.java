/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191021;

/**
 *
 * @author xvpow
 */
public class Ch16_4 {

    //lambda
    //一定是FunctionalInterface
    //如果參數是一個可以不用加()
    //如果沒有{}不可加上;
    static void test1(String s,MyPrint p){
        p.print(s);
    }
    
    static int test2(int a,int b,Calculator c){        
        return c.calcu(a, b);
    }
    
    static String[] copyArray(String[] src,CopyArray copyArray){
       String[] tmpArray =  copyArray.copy(src);
       return tmpArray;
    }
    
    static String[] copyArrayMethod(String[] src){
        String[] copy = new String[src.length];
        for (int i = 0; i< src.length;i++){
            copy[i] = src[i];
        }
        return copy;
    }
    
    public static void main(String[] args) {
         //如果沒有{}不可加上;
        test1("Iris",v->System.out.printf("value:"+v));
        test1("Ken",(v)->{System.out.printf("value:"+v);});
        System.out.println();
        
       int asn =  test2(10,20,(a1,a2)->{ return a1 + a2; });
       System.out.println(asn);
       asn = test2(2,5,(a1,a2)->a1 * a2 );
        System.out.println(asn);
        String[] names = {"Ken","Vivin","Lindy"};
        //method reference
        String[] copy = copyArray(names,Ch16_4::copyArrayMethod);
        System.out.println(copy[1]);
    }
    
}
