/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191021;     
import ch16_20191021.Ch16_1.MyInner;
public class Ch16_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Ch16_1 myObj = new Ch16_1();
        MyInner myInner = myObj.new MyInner("c",20);
        Ch16_1.MyStaticInner ms1 = new  Ch16_1.MyStaticInner(17.5f,"Apple pen");
        Ch16_1.MyStaticInner ms2 = new  Ch16_1.MyStaticInner(17.5f,"Apple pen");   
        System.out.println(ms1.equals(ms2));
    }
    
}
