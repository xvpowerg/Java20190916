/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191021;

/**
 *
 * @author xvpow
 */
public class Ch16_3 {

    //匿名內部類
    static void print(Dog dog){
        dog.bark();
    }
    
    static boolean testMax(int a,int b,MyCompare myCompare){
        return myCompare.max(a, b);
    }
    
    static class MyDog extends Dog{
        public void bark(){
            System.out.println("喵喵!!");
        }
    }
    
    static class TestMax implements MyCompare{
            public boolean max(int a,int b){
                return a >b;
            }
    }
    public static void main(String[] args) {
        Dog dog1 = new Dog();
        print(dog1);
        MyDog myDog = new MyDog();
        print(myDog);
        
        //匿名內部類
        print(new MyDog(){
            public void bark(){
                System.out.println("支支叫");
            }        
        });
        
        System.out.println(testMax(50,20,new TestMax()));
        
        
         System.out.println(testMax(10,70,new MyCompare(){
             public boolean max(int a,int b){
                 return b > a;
             }
         })); 
         
       //lambda
      System.out.println(testMax(10,70,(a,b)->{return b >a;}));
      System.out.println(testMax(10,70,(a,b)-> b >a ));
         
    }
    
}
