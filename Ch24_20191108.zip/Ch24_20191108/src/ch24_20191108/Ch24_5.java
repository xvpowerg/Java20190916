/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;


public class Ch24_5 {

 
    public static void main(String[] args) {
        //反序列化
        //把以序列化的檔案轉成物件
        File target = new File("/Users/shihhaochiu/Documents/javadir/list.dao");
   
        try(FileInputStream fIn = new FileInputStream(target);
             ObjectInputStream objIn = new ObjectInputStream(fIn);   
                ){
          ArrayList<String> list = (ArrayList) objIn.readObject();
            list.forEach(System.out::println);
        }catch(IOException | ClassNotFoundException ex){
            System.out.println(ex);
        }
        
        
    }
    
}
