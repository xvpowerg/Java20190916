/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;

import java.nio.file.Path;
import java.nio.file.Paths;
public class Ch24_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Path path =  Paths.get("..","/",".","..");
      System.out.println(path.normalize()); 
      Path path2 = Paths.get("/","Users","shihhaochiu","Documents/javadir/");
      Path path3= Paths.get("resolve.txt");
      System.out.println(path2.resolve(path3)); 
     Path path4= Paths.get("/","resolve.txt");
     System.out.println(path2.resolve(path4)); 
      
    }
    
}
