/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.util.ArrayList;
public class Ch24_4 {


    public static void main(String[] args) {
     //序列化
       //序列化  把物件變檔案
       //反序列化 把檔案變物件
     ArrayList<String> arrayList = new ArrayList<>();
       arrayList.add("Ken");
       arrayList.add("Vivin"); 
       arrayList.add("Lindy"); 
       arrayList.add("Join"); 
        File target = new File("/Users/shihhaochiu/Documents/javadir/list.dao");
     
       try(  FileOutputStream fout = new FileOutputStream(target);
               ObjectOutputStream oos = new ObjectOutputStream(fout)){
           oos.writeObject(arrayList);
       }catch(IOException ex){
           System.out.println(ex);
       }
       
    }
    
}
