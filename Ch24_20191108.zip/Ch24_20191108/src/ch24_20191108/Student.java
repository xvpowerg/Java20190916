/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;

import java.io.Serializable;

/**
 *
 * @author shihhaochiu
 */
public class Student extends Person implements Serializable{
    private int age;
    private String name;
    
    public Student(int age,String name,
            String address,float height){
        super(address,height);
        this.age = age;
        this.name = name;
    }
    
    public String toString(){
        return name+":"+age;
    }
    
}
