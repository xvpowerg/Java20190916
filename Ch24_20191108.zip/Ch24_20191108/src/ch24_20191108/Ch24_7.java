/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
public class Ch24_7 {

    
    public static void main(String[] args)throws Exception {
           File target = new File("/Users/shihhaochiu/Documents/"
                  + "javadir/student.dao");
           
           try(FileInputStream fin = new FileInputStream(target);
                ObjectInputStream objIn = new  ObjectInputStream(fin);  ){
              Student student = (Student) objIn.readObject();
              System.out.println(student);
           }
           
    }
    
}
