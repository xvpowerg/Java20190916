/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

public class Ch24_8 {


    public static void main(String[] args) {
        Path path1 = Paths.get("/","Users","shihhaochiu","Documents/javadir/test1.txt");
        System.out.println(path1.getFileName());
        System.out.println(path1.getName(1));
       System.out.println(path1.getRoot());
       
        System.out.println(path1.subpath(1, 4));
        System.out.println(path1.getNameCount());
        
        
      
    }
    
}
