/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;
import java.io.FileReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch24_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       File file = new File("/Users/shihhaochiu/Documents/javadir/myword.txt");
       try(FileReader fRead = new FileReader(file);){
           
           int value = -1;
           
           while( (value =fRead.read()) != -1  ){
               System.out.print((char)value);
           }
             
       }catch(FileNotFoundException fe){
           System.out.println(fe);
       }catch(IOException ex){
            System.out.println(ex);
       }
     
    }
    
}
