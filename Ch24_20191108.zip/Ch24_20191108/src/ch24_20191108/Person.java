/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;

import java.io.Serializable;

/**
 *
 * @author shihhaochiu
 */
public class Person {
    private String address;
    private float height;
    public Person(){
        
    }
    public Person(String address,float height){
        this.address = address;
        this.height = height;
    }
    
    public String toString(){
        return address+":"+height;
    }
}
