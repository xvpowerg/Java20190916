/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
/**
 *
 * @author shihhaochiu
 */
public class Ch24_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      File srcFile = new  File("/Users/shihhaochiu/Documents/javadir/java-test.zip");
      File targetSrc = new File("/Users/shihhaochiu/Documents/javadir/java-test_copy.zip");
      
      try (FileInputStream fileIn = new FileInputStream(srcFile);
           FileOutputStream fileOut = new FileOutputStream(targetSrc);){
          
           int index = -1;
           byte[] buffer = new byte[2048];
           while( (index = fileIn.read(buffer)) != -1){
               fileOut.write(buffer,0,index);
           }
          
          
      }catch(FileNotFoundException ex){
          System.out.println(ex);
      }catch(IOException ex){
           System.out.println(ex);
      }
      
    }
    
}
