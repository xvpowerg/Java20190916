/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;
import java.io.File;
import java.io.FileWriter;

/**
 *
 * @author shihhaochiu
 */
public class Ch24_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
            
            String msg = "Test Writer File....";
            File target = new File("/Users/shihhaochiu/Documents/javadir/testwrite.txt");
            try(FileWriter fileWrite = new FileWriter(target);){
                fileWrite.write(msg);
                
            }
    }
    
}
