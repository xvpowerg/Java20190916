/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191108;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author shihhaochiu
 */
public class Ch24_6 {
    public static void main(String[] args) throws Exception{
        Student st1 = new Student(25,"Ken","Addreass,,",178.2f);
        
          File target = new File("/Users/shihhaochiu/Documents/"
                  + "javadir/student.dao");
     
       try(  FileOutputStream fout = new FileOutputStream(target);
               ObjectOutputStream oos = new ObjectOutputStream(fout)){
           oos.writeObject(st1);
           
       }
    }
    
}
