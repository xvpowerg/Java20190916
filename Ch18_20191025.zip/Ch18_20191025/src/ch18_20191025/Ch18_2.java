/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191025;
import java.util.ArrayList;
public class Ch18_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Integer> list2 = new ArrayList<>();
        list2.add(60);
        list2.add(30);
        list2.add(20);
        int sum= 0;
        for (Integer v : list2){
            sum += v;
        }
        System.out.println(sum);
    }
    
}
