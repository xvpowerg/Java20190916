/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191025;
import java.util.ArrayList;
/**
 *
 * @author xvpow
 */
public class Ch18_4 {

    public static void main(String[] args) {
        Item item1 = new Item("iPhone 8",1000);
        Item item2 = new Item("小米8",500);
        Item item3 = new Item("PC",600);
        
        Item removeItem = new Item("小米8",500); 
        ArrayList<Item> list = new ArrayList<>();
        list.add(item1);
        list.add(item2);
        list.add(item3);
        
        list.remove(removeItem);
        System.out.println(
                removeItem.equals(item2));
        for (Item i : list){
            System.out.println(i);
        }
        
    }
    
}
