/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191025;
import java.util.HashSet;
public class Ch18_7 {

    public static void main(String[] args) {
                //無順序 
        HashSet<Integer> set = new HashSet<>();
        set.add(20);
        set.add(10);
        set.add(95);
        set.add(10);
        set.add(70);
        boolean b1 =  set.contains(95);
        System.out.println(b1);
       b1 =  set.contains(31);          
       System.out.println(b1);
        for (int v : set){
            System.out.print(v+" ");
        }
        
    }
    
}

