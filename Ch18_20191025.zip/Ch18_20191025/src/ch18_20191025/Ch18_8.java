/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191025;
import java.util.LinkedHashSet;
/**
 *
 * @author xvpow
 */
public class Ch18_8 {

    public static void main(String[] args) {
        //有順序 順序依照放進去的先後
     LinkedHashSet<Integer> linkedSet = new LinkedHashSet<>();
     linkedSet.add(20);
     linkedSet.add(10);
     linkedSet.add(80);
     linkedSet.add(10);
     linkedSet.add(90);
     
     for (int v : linkedSet){
         System.out.print(v+" ");
     }
     
    }
    
}
