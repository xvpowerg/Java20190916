/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191025;
import java.util.LinkedList;
import java.util.List;
public class Ch18_5 {
    
    static void foreach(List<Integer> list){
        for (int v : list){
            System.out.print(v+" ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
      LinkedList<Integer> list = new LinkedList<>();
      list.add(20);
      list.add(15);
      list.add(71);
      list.add(25);
      
      //讀取的list的第一筆數值
      int peek = list.peek();
      System.out.println("peek:"+peek);
     foreach(list);
     //先讀取再移除
     int poll = list.poll();
     System.out.println("poll:"+poll);
      foreach(list);
      
    }
    
}
