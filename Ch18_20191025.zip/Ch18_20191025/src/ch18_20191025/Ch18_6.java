/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191025;
import java.util.LinkedList;
public class Ch18_6 {

  
    public static void main(String[] args) {
       LinkedList<Integer> list = new LinkedList<>();
      list.add(20);
      list.add(15);
      list.add(71);
      list.add(25);
      
      Integer value = list.poll();
      while(value != null){
          System.out.print(value+" ");
          value = list.poll();
      }
      
//      Integer value = null;
//      while(  (value = list.poll() )  != null ){
//          System.out.print(value+" ");
//      }
      
      
      //list.poll() while
//      Object obj = list.poll();
//      System.out.println(obj);
//          obj = list.poll();  
//       System.out.println(obj);   
       
       
       
    }
    
}
