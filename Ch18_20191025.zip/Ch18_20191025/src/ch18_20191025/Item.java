/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191025;

/**
 *
 * @author xvpow
 */
public class Item {
    private String name;
    private int price;
    public Item(String name,int price){
        this.name = name;
        this.price = price;
    }
    public String toString(){
        return name+":"+price;
    }
    
    public boolean equals(Object obj){
        if (obj == null || obj instanceof Item == false){
            return false;
        }
          Item tmpItem = (Item)obj;
        return tmpItem.name.equals(this.name) &&
                tmpItem.price == this.price;
    }
}
