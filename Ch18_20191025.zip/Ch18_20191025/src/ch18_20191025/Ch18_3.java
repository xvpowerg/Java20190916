/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191025;

import java.util.ArrayList;

/**
 *
 * @author xvpow
 */
public class Ch18_3 {

    public static void main(String[] args) {
       ArrayList<Integer> list = new ArrayList<>();
       list.add(25);
       list.add(30);
       list.add(10);
       list.add(1,26);
       
       System.out.println(list.get(3));
       list.remove(Integer.valueOf(10));
       
       list.replaceAll(v->v+5);
       
       ArrayList<Integer> list3 = new ArrayList();
       list3.add(91);
       list3.add(51);
       list3.add(81);
       list.addAll(list3);
       
       for (int v :list){
           System.out.print(v+" ");
       }
       
    }
    
}
