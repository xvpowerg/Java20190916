/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191025;
import java.util.ArrayList;
public class Ch18_1 {

    public static void main(String[] args) {
        //List 像是無限長度的陣列  
        //Set 無重複元素的陣列
        //Map Key Value
        
        ArrayList list = new ArrayList();
        list.add(10);
        list.add(50);     
        list.add(20);  
        
        
//        for (int i = 0; i < list.size();i++){
//            System.out.println(list.get(i));
//        }
        int  sum = 0;
        for (Object obj : list){
           // sum += obj;
             sum +=(Integer)obj;         
        }
        System.out.println(sum);
        
    }
    
}

