/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191004;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private int score;//0~100
    //例外分兩種
    //必要例外檢測 所有繼承RuntimException都是非必要例外 不一定要try catch
    //非必要例外檢測 直接繼承Exception都是都是一定要try catch
    public Student(String name){
        this.name = name;
    }
    
    public void setName(String name)throws java.io.IOException{
        if (name == null){
           throw new java.io.IOException("name 不可為 null");
        }
        this.name = name;
    }
    public void setScore(int score){
        if (score < 0 || score > 100){
//            System.out.println("錯誤的成績:"+score);
//            return;
         throw new java.lang.IllegalArgumentException("錯誤的成績:"+score);
        }
        this.score = score;
    }
    public void print(){
        System.out.println(name+":"+score);
    }
    
    
}
