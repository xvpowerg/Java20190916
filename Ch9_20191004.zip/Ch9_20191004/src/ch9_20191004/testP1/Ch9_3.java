/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191004.testP1;
import ch9_20191004.TestClass1;
public class Ch9_3 extends TestClass1{

    public static void main(String[] args) {
       TestClass1 t2 = new TestClass1();
       System.out.println(t2.publicValue);
       
       TestClass2 t3 = new TestClass2();       
       t3.printProtected();
    }
    
}
