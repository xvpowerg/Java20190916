package ch9_20191004.testP1;
import ch9_20191004.TestClass1;
public class TestClass2 extends TestClass1{
    public  TestClass2(){
        this.protectedValue = "TestClass2 protectedValue";
    }
  void printProtected(){
      System.out.println(protectedValue);
  }    
}
