/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191004;

/**
 *
 * @author xvpow
 */
public class TestClass1 {
    /* 必考!!!!
     屬性預設值:
     整數系列:0
     浮點數系列:0.0
     字元:空白字元
     布林:false
    */
    //全都可讀 跨Pacakge記得import
    public String publicValue;
    //有相同package可以讀 or 在子類別內可讀取
    protected String protectedValue;
    //只有相同package可以讀
    String defaultValue;
    //只有自己的類可呼叫
    private String privateValue;    
     public TestClass1(){
        publicValue = "TestClass1 publicValue";
        protectedValue = "TestClass1 protectedValue";
        defaultValue = "TestClass1 defaultValue";
        privateValue = "TestClass1 privateValue";       
    }
    
    
}
