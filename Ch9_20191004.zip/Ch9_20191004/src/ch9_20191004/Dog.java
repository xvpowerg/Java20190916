/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191004;
public class Dog extends Animal {
    //所有建構子都預設呼叫super()
    //如果呼叫了this(xx,xxx) or super(xxx)就不會呼叫super()
    public Dog(String name,int age){        
        super(name,age);
    }
    
    public void print(){
        System.out.print("Dog:");
        super.print();
    }
}
