/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191004;
public class Ch9_1 {

    public static void main(String[] args) {
        Animal an1 = new Animal("Dog",5);
        an1.print();
       Animal an2 = new Animal("Dog",5);
       an2.setName("Cat");
       an2.setAge(3);       
       an2.print();
       
       Dog d1 = new Dog("LuLu",6);
       d1.print();//Dog:LuLu:6
       
       Cat cat1  = new Cat("Kitty",25);
       cat1.print();//Cat:Kitty:25
    }
    
}
