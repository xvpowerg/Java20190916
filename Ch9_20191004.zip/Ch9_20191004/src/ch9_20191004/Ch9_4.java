package ch9_20191004;
public class Ch9_4 {
    public static void main(String[] args) {
       Student st1 = new Student("Ken");
       st1.setScore(50);
       st1.print();
       try{
          st1.setScore(-25);
          st1.print();
       }catch(java.lang.IllegalArgumentException ex){
           System.out.println("錯誤:"+ex);
       } 
       
      Student st2 = new Student("Vivin");
       st2.setScore(31);
       
       try{
         st2.setName(null);   
       }catch(java.io.IOException ex){
           System.out.println(ex);
       }
      
       st2.print();
       
    }    
}
