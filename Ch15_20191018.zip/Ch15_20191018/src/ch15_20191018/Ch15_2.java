/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;

/**
 *
 * @author xvpow
 */
public class Ch15_2 {

    public static void main(String[] args) {
        
    MyId myId = new MyId(new TestSupplierDefault());
    System.out.println(myId.generateId());
    myId.setGenerate(new TestSupplier2());
    System.out.println(myId);
    //再做一組Supplier generateId 1~100
        // TestSupplier2 1~100
    }
    
}
