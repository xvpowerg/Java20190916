/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;
import java.util.function.Consumer;
/**
 *
 * @author xvpow
 */
public class MyConsumerDWH implements Consumer<Integer> {
    private static String[] MSG={"D","W","H"};
    private int index = 0;
    public void accept(Integer v){
        System.out.printf("%s:%d ",MSG[index++],v);
    }
}
