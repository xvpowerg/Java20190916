/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;
import java.util.function.Supplier;
import java.util.Random;

public class TestSupplierDefault implements Supplier<Integer> {
    public Integer get(){
        Random ran = new Random();
        return ran.nextInt(9000);
    }
}
