/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
/**
 *
 * @author xvpow
 */
public class Product {
   private int[] volume = new int[3];
   private String name;
   private int price;
   public final static  int MAX = 90000;
   public final static  int MIN = 1000;
   
   public boolean testPrice(Predicate<Integer> pred){
       return pred.test(price);
   }
   public static Product newProduct(Function<String[],Product> f,
                                    String[] array){
       return f.apply(array);
   }
   public Product(String name, int price){
       this.name = name;
       this.price = price;
   }
   public void addVolume(int d,int w,int h){
       volume[0]=d;
       volume[1]=w;
       volume[2]=h;
   }

   public void printVolume(Consumer<Integer> consumer){
   
       for (int v : volume){
            consumer.accept(v);
       }
     
      
   }
   
   public String toString(){
       return name+":"+price;
   }
}

