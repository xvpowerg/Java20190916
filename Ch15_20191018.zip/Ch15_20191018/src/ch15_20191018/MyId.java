/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;
import java.util.function.Supplier;
public class MyId {
    private Supplier<Integer> idSupp = null;
    public MyId(Supplier<Integer> idSupp){
        this.idSupp = idSupp;
    }
    public void setGenerate(Supplier<Integer> idSupp){
           this.idSupp = idSupp;
    }
   public  int generateId( ){
       return idSupp.get();
   }  
}
