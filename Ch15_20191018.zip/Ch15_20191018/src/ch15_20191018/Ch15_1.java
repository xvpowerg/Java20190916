/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;
import java.util.function.Consumer;
/**
 *
 * @author xvpow
 */
public class Ch15_1 {
    public static void main(String[] args) {
      //Consumer<T> void accept(T t)
      //Function<T,R> R	apply(T t)
      //Predicate<T> boolean test(T t)
      //Supplier<T> T	get()
      //UnaryOperator<T> T apply(T t)
      
      Product p1 = new Product("iPhone",18000);
      System.out.println(p1);
      p1.addVolume(10,180, 250);
      //new MyConsumerInt();
      Consumer myC1 = new MyConsumerDWH();
      p1.printVolume(myC1);
      //p1.printVolume(myC1);    
       System.out.println();
      Product p2 = Product.newProduct(new MyFunction(),
              new String[]{"eBook","5000"});
        System.out.println(p2);
       boolean b1 =  p2.testPrice(new TestPredicateDefault());
       System.out.println(b1);
       
    Product  p3 = Product.newProduct(new MyFunction(),
            new String[]{"Andorid Phone","5"});
       boolean b3 =  p3.testPrice(new TestPredicate2());
      System.out.println(b3);
       //TestPredicate2
       //max = 10000 min=10
    }
    
}
