/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;
import java.util.function.Supplier;
/**
 *
 * @author xvpow
 */
public class TestSupplier2 implements  Supplier<Integer>{
    public Integer get(){
        java.util.Random ran = new  java.util.Random();
        return ran.nextInt(100) +1;
    }    
}
