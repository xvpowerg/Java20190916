/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;

@FunctionalInterface
public interface TestIf {
    //FunctionalInterface 抽象的方法只有一個
    void test1();
    default void t1(){
        
    }   
    static void s1(){
        
    }
}
