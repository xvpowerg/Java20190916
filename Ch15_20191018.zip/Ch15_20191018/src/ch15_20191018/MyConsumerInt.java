/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;
import java.util.function.Consumer;
public class MyConsumerInt implements Consumer<Integer>{
    public void accept(Integer i){
        System.out.print(i+" ");
    }
}
