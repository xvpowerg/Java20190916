/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191018;
import java.util.function.Function;
/**
 *
 * @author xvpow
 */
public class MyFunction implements 
                Function<String[],Product>{
    public Product apply(String[] s){
        Product tmp = 
                new Product(s[0],Integer.parseInt(s[1]));
        return tmp;
    }
}
