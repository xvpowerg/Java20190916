/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.erpro.report;
import java.util.ArrayList;
import tw.com.erpro.MyErp;
/**
 *
 * @author xvpow
 */
public class MyRepor extends MyErp {
    public void genereatReport(ArrayList<String> data){
        for (String v :  data){
            //System.out.println(v);
             String[] detailData =  v.split(",");
             System.out.printf("姓名:%s 第一季:%s 第二季%s 第三季%s%n",
                     detailData[0],detailData[1],detailData[2],detailData[3]);
             
        }
    }
    public static void  main(String[] args){
         MyRepor mr = new MyRepor();
         mr.exportReport();
    }
}
