/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.erpro;
import java.util.ArrayList;
import java.util.stream.Stream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.stream.Collectors;
public abstract class MyErp {
   ArrayList readData(){
       try{
            Path p1 = Paths.get("C:", "MyDir","data.txt");
            Stream<String>  dataStream = Files.lines(p1);
            return dataStream.collect(Collectors.toCollection(ArrayList::new));
       }catch(IOException ex){
           System.out.println(ex);
       }   
       return null;
   }
   public void exportReport(){
     ArrayList data = readData();
     genereatReport(data);
   }
   protected  abstract void genereatReport(ArrayList<String> data);
   
//   public static void main(String[] args){
//       MyErp.readData();
//   }
   
}
