/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20191111;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
/**
 *
 * @author shihhaochiu
 */
public class Ch25_2 {

    public static void main(String[] args) {
       
      /* Path  srcPath=  Paths.get("/Users/shihhaochiu/Documents/javadir/myword.txt");
       
       try{
        List<String> list =  Files.readAllLines(srcPath);
        list.stream().forEach(System.out::println);
       }catch(IOException ex){
           System.out.println(ex);
       }*/
      Path  targetPath=  Paths.get("/Users/shihhaochiu/Documents/javadir/testWrite.txt");
      ArrayList<String> myStrList = new ArrayList<>();
      myStrList.add("Hi...");
      myStrList.add("Howard");
      myStrList.add("Ken");
      try{
         Path path =   Files.write(targetPath, myStrList);
      }catch(IOException ex){
          System.out.println(ex);
      }
       
        
    }
    
}
