/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20191111;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.stream.Stream;
/**
 *
 * @author shihhaochiu
 */
public class Ch25_3 {

    public static void main(String[] args) {
       ///Users/shihhaochiu/Documents/javadir
     Path path =   Paths.get("/Users/shihhaochiu/Documents/javadir/javadir_file.txt");
//     try{
//           Stream<String> stream=  Files.lines(path);
//           stream.forEach(System.out::println);
//     }catch(IOException ex){
//         System.out.println(ex);
//     }

  Path dirPath =   Paths.get("/Users/shihhaochiu/Documents/javadir");
//     try{
//         //Files.list 顯示目前單一層目錄
//       Stream<Path> strPath =  Files.list(dirPath);  
//       strPath.forEach(System.out::println);
//     }catch( IOException ex){
//         System.out.println(ex);
//     }
   try{
        Stream<Path> strPath = Files.walk(dirPath, 2);  
        strPath.forEach(System.out::println);
   }catch(IOException ex){
       
   }
       
    }
    
}
