/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20191111;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import static  java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import static  java.nio.file.StandardCopyOption.ATOMIC_MOVE;
import static  java.nio.file.StandardCopyOption.COPY_ATTRIBUTES;
public class Ch25_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Path srcPath   = Paths.get("/Users/shihhaochiu/Documents/javadir/java-test.zip");
       Path targetPath   = Paths.get("/Users/shihhaochiu/Documents/javadir/test_move/java-test-copy-move.zip"); 
       /*try{
           Files.copy(srcPath, targetPath,COPY_ATTRIBUTES,REPLACE_EXISTING);
       }catch(IOException ex){
          System.out.println(ex);
       }*/
       try{
           Files.move(srcPath, targetPath,ATOMIC_MOVE);
       }catch(IOException ex){
            System.out.println(ex);
       }
      
        
    }
    
}
