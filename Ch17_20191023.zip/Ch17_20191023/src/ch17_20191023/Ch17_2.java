/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20191023;

/**
 *
 * @author xvpow
 */
public class Ch17_2 {
    enum Fruit{
        APPLE,
        KIWI,
        BANANA
    }
  
    public static void main(String[] args) {
//        Fruit kiwi =  Fruit.valueOf("KIWI");
//        System.out.println(kiwi);
//        Fruit.valueOf("Charry");
//        
//        Fruit f = Fruit.APPLE;
//        System.out.println(f);
       
       

      Fruit[] fa=  Fruit.values();
       for (Fruit fx : fa){
           System.out.println(fx);
       }
        
      System.out.println(Fruit.KIWI.name());
      System.out.println(Fruit.KIWI.ordinal());
      System.out.println(Fruit.KIWI.toString());
       
        switch(Fruit.APPLE){
            case APPLE:
                System.out.println("59");
                break;
            case KIWI:
                System.out.println("10");
                break;
            case  BANANA:
                 System.out.println("15");
                break;
        }
    }
    
}
