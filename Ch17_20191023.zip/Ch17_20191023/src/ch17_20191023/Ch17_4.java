/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20191023;

public class Ch17_4 {
    
    public static void main(String[] args) {
        //String  不會改變來源
        String value = "123456789";
        System.out.println(value.concat("ABCD"));
        System.out.println(value);  
        //低階設備傳輸
         System.out.println(value.getBytes()[1]);   
         //如果有回傳相對應Index 如果無回傳-1
        System.out.println(value.indexOf("6"));  
        System.out.println(value.indexOf("A"));  
        System.out.println(value.substring(4));  
        System.out.println(value.substring(2,6)); 
    }
    
}
