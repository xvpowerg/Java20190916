/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20191023;

/**
 *
 * @author xvpow
 */
public class Ch17_3  {
    enum Animal  implements MyIF{
        DOG("Sonppy"),
        TIGER{           
            public String toString(){
                return "老虎";
            }
        },
        CAT;
      private String animalName;
      private Animal(){
          this.animalName = "無名";
      }  
      
     private Animal(String name){
          this.animalName = name;
      }
      
      public String toString(){
          return "動物:"+super.toString()+":"+animalName;
      }
    }

    public static void main(String[] args) {

      System.out.println(Animal.CAT);  
      System.out.println(Animal.TIGER);      
       System.out.println(Animal.DOG);      
    }
    
}
