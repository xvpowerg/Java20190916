/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20191023;
import java.util.function.Function;
        
public class Ch17_1 {

    static void testFunction(int v,Function<Integer,String> function){
        System.out.println(function.apply(v));
    }
    
   static void testFunction2(String name,Function<String,Item> function){
        System.out.println(function.apply(name));
    }
    static class MyFunction implements Function<Integer,String>{
        public String apply(Integer v){
            return "金額:"+String.valueOf(v);
        }
    }
    
    public static void main(String[] args) {
         testFunction(35,String::valueOf);     
     testFunction2("iPhone",Item::new);
        
        
       //testFunction(56,new MyFunction());
       
//     testFunction(12,new Function<Integer,String>(){       
//           public String apply(Integer v){
//               return "費用:"+v;
//           }
//       }); 
     
     //testFunction(82,(v)->"金額:"+String.valueOf(v));
    
     
    }
    
}
