/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191030;
import java.util.HashMap;
public class Ch20_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap<String,Integer> map = new HashMap();
        map.put("Ken", 71);
        map.put("Vivin", 83);
        map.put("Lindy", 94);
        //Key 不可重複 重複就覆蓋
       map.put("Lindy", 82);  
       map.forEach((k,v)->{System.out.println(k+":"+v);});
       
      if (!map.containsKey("Lindy")) {
          map.put("Lindy",95);
      }
         if (!map.containsKey("Iris")) {
          map.put("Iris",95);
      }
      System.out.println(map.get("Lindy"));
      System.out.println(map.get("Iris"));
      
      map.putIfAbsent("Ken", 32);
      map.putIfAbsent("Join", 79);
      System.out.println(map.get("Ken"));
      System.out.println(map.get("Join"));
       //Ken Key 存在可合併
      map.merge("Ken", 85, (i1,i2)->{
          System.out.println(i1+":"+i2);
          return i1+i2;});
       System.out.println(map.get("Ken"));
       //Tom Key 不存在直接回傳31
       map.merge("Tom", 31, (i1,i2)-> {
           return i1+i2;});
        System.out.println(map.get("Tom"));
        
        
        
    }
    
}
