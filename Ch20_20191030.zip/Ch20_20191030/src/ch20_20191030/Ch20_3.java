/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191030;

import java.util.HashMap;

/**
 *
 * @author shihhaochiu
 */
public class Ch20_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap<String,Integer> map = new HashMap();
        map.put("Ken", 71);
        map.put("Vivin", 83);
        map.put("Lindy", 94);
        map.put("Iris", 75);
        
        //Key存在
       //Key存在執行
       map.compute("Ken", (key,value)->{
           System.out.println("compute Ken....:"+value);
           return 76;});
        System.out.println(map.get("Ken"));
       //Key存在不執行
        map.computeIfAbsent("Vivin",(key)-> 10);
        System.out.println(map.get("Vivin"));
       // map.computeIfPresent(key, remappingFunction)
       map.computeIfPresent("Lindy",(key,value)->{
           System.out.println("computeIfPresent ....");
           return value+20;} );
       System.out.println(map.get("Lindy"));
       //Key不存在
       
        //Key不存在執行
       map.compute("Join", (key,value)->{
           System.out.println("compute Join....:"+value);
           return 76;});
        System.out.println(map.get("Join"));
       //Key不存在執行
        map.computeIfAbsent("Gigi",(key)-> 10);
        System.out.println(map.get("Gigi"));
       //Key不存在不會執行
      map.computeIfPresent("Lucy",(key,value)->{
           System.out.println("computeIfPresent ....");
           return value+20;} );
       System.out.println(map.get("Lucy"));
       
    }
    
}
