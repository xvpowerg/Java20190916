/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191030;
import java.util.TreeSet;
import java.util.Comparator;
public class Ch20_1 {

   
    public static void main(String[] args) {
//       TreeSet<Item> set = new TreeSet<>((i1,i2)->{
//            if(i1.getPrice() > i2.getPrice()){
//                return 1;
//            }else if(i1.getPrice() < i2.getPrice()){
//                return -1;
//            }
//            return 0;
//           }  );

//       TreeSet<Item> set = new TreeSet<>(Comparator.
//                                comparing((i)->i.getPrice()) );
Comparator myCmp = Comparator.<Item,Integer>
                   comparing((i)->i.getPrice()).
                   thenComparing(i->i.getName()).
                   thenComparing(i->i.getData()).reversed();

  TreeSet<Item> set = new TreeSet<>(myCmp);
       //int price,String name,int data
        Item i1= new Item(100,"XBox",20190325);
        Item i2= new Item(50,"Java",20191020);
        Item i3= new Item(72,"Objetc",20180511);
        Item i4= new Item(63,"C#",20190713);
        Item i5= new Item(63,"Arduino",20190813);
        Item i6= new Item(63,"Arduino",20190913);
        set.add(i1);
        set.add(i2);
        set.add(i3);
        set.add(i4);
        set.add(i5);
        set.add(i6);
        
        set.stream().forEach(System.out::println);
    }
    
}
