/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191030;
import java.util.ArrayList;
import java.util.HashMap;
public class Ch20_4 {

    public static void main(String[] args) {
       ArrayList <Item> list = new ArrayList();
        Item i1 = new Item(15,"iPad",20160216);
        Item i2 = new Item(80,"Goole",20170216);
        Item i3 = new Item(25,"Goole",20170321);
        Item i4 = new Item(12,"iPad",20130910);
        Item i5 = new Item(16,"android",20160718);
        Item i6 = new Item(350,"iPad",20171010);
        
        list.add(i1);
        list.add(i2);
        list.add(i3);
        list.add(i4);
        list.add(i5);
        list.add(i6);
      
       HashMap<String,ArrayList<Item>> map = new HashMap<>();  
//       for (Item it : list){
//           ArrayList<Item> tmpList = new ArrayList<>();
//           String key = it.getName();
//           if (map.containsKey(it.getName())){
//               tmpList = map.get(key);
//           }
//           tmpList.add(it);
//           map.put(key, tmpList);
//       }
  for (Item it : list){
      map.computeIfPresent(it.getName(), (k,lsit)->{
          lsit.add(it);
          return lsit;});
      
      map.computeIfAbsent(it.getName(), (k)->{
      ArrayList<Item> newList = new ArrayList<>();
      newList.add(it);
      return newList;
      });
      
  }
       
       System.out.println(map);
    }
    
}
