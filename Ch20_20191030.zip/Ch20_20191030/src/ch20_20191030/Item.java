/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191030;

/**
 *
 * @author shihhaochiu
 */
public class Item {
    private int price;
    private String name;
    private int data;
    public Item(int price,String name,int data){
        this.price = price;
        this.name = name;
        this.data = data;
    }
    
    public String getName(){
        return name;
    }
    public int getPrice(){
        return price;
    }
    public int getData(){
        return data;
    }
    
    public String toString(){
        return name+":"+price+":"+data;
    }
    
}
