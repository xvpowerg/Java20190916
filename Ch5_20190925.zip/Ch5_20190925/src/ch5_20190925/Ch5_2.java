/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190925;

/**
 *
 * @author xvpow
 */
public class Ch5_2 {
      static void swap(int a1,int a2){        
        int tmp = a1;
        a1 = a2;
        a2 = tmp;
      }
      static void swapArray(int[] array){
          int tmp = array[0];
          array[0] = array[1];
          array[1] = tmp ;
      }
    public static void main(String[] args) {
         //對於傳入變數的影響性
        //call by value ->所有基本型態
//        int a1 = 10;
//        int a2 = 32;
//        swap(a1,a2);
//        System.out.println(a1+":"+a2);

        //call by reference->非基本型態的
         int[] array = {5,2};
          swapArray(array);
          System.out.println( array[0]+":"+array[1]);
                 
        
        
        
    }
    
}
