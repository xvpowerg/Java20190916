/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190925;

/**
 *
 * @author xvpow
 */
public class Ch5_4 {
    //Vargs
    //只能是最後一個參數
    static int sum(int... a1){
        int ans = 0;
        for (int v :a1){
            ans += v;
        }
        return ans;
    }
    public static void main(String ... args) {
        
        System.out.println(sum(5,2,6,1,2,4,8,9));
        System.out.println(sum(1,2,7));
        
    }
    
}
