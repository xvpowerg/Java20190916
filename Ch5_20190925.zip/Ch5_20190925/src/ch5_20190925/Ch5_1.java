/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190925;

/**
 *
 * @author xvpow
 */
public class Ch5_1 {

    //方法 method
    //必要元素
    //回傳值類型
       //void 表示無回傳值
    //方法名稱
    //傳入參數
    
    //static 只能呼叫 static的
    static void test1(){        
        System.out.println("Hello!!");
    }
    static int test2(int a1,int a2){
        int ans = a1 + a2;
        //1 離開方
        //2 回傳數值
        return ans;
    }
    
    static int test3(int n1,int n2){
        int ans = 1;          
        for (int i = 1; i<= n2;i++){
            ans *= n1;
        }        
        return ans;
    }
    
    
    public static void main(String[] args) {
          //test1();  
          int t2 = test2(5,2);
          System.out.println(t2);
          System.out.println(test2(5,2));
          System.out.println(test3(2,3));
          System.out.println(test3(5,2));
          
          
    }
    
}
