/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190925;
import java.util.Scanner;
import java.util.Random;
public class Ch5_6 {
    static int genRandomNumber(int max){
         Random rand = new Random();
        return  rand.nextInt(max) + 1;
    }
    
    static void game(int max){
      Scanner scan = new Scanner(System.in);      
       int min=1;
       int guess = genRandomNumber(max);              
       while(true){
        System.out.printf("%d~%d:",min,max);     
         int keyin = scan.nextInt();
           if (keyin == guess){
               System.out.println("猜對了!");
               break;
           }else if(keyin >guess){
               max = keyin;
           }else{
               min = keyin;
           }
       }
    }
    public static void main(String[] args) {
        game(10);
        game(20);
        game(30);      
    }
    
}
