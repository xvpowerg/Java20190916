/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190927;

/**
 *
 * @author xvpow
 */
public class Ch6_2 {
    public static void main(String[] args) {
        //Integer.valueOf 會暫存 1個byte的數字區間 (-128~127)
        Integer i1 = Integer.valueOf(5);
        Integer i2 = Integer.valueOf(5);        
        System.out.println(i1 == i2);
        
        Integer i3 = Integer.valueOf(-128);
        Integer i4 = Integer.valueOf(-128);        
        System.out.println(i3 == i4);
        
        //自動封箱使用valueOf
        Integer b1 = 10;
        Integer b2 = 10;
        System.out.println(b1 == b2);
        Integer b3 = 128;
        Integer b4 = 128;
        System.out.println(b3 == b4);
        
        
    }
    
}
