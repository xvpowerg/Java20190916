/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190927;

/**
 *
 * @author xvpow
 */
public class Ch6_7 {
   /* 1 找相同類型
      2 找同類型可相容的
      3 找其他同類型可相容的
      4 轉成封箱
    */
    
    static void test1(float f1,int i2){
        System.out.println("float int");
   }    
//    static void test1(int i1,int i2){
//        System.out.println("int int");
//    }
    
     static void test1(int i1,float i2){
        System.out.println("int float");
    }
    
    public static void main(String[] args) {
      //test1(7,5);
     // test1(8.5f,5);   
    }
    
}
