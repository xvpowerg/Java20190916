/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190927;

/**
 *
 * @author xvpow
 */
public class Ch6_3 {

   
    public static void main(String[] args) {
       //字串轉int
       String priceStr = "25";
       int price =  Integer.parseInt(priceStr);
       System.out.println(price + 1);
       
      System.out.println("開始" );
       String priceStr2 = "12";
       int price2 =  Integer.parseInt(priceStr2);
       System.out.println(price2 );
        System.out.println("完成" );
        
        
        
        
    }
    
}
