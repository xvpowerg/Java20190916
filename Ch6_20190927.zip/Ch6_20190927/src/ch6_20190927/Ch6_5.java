/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190927;

/**
 *
 * @author xvpow
 */
public class Ch6_5 {
    //多載(OverLoading)口訣:方法名稱要一樣 傳遞的參數 類型或數量 不一樣
    static int test1(int value1,int value2){       
        return test1(value1,value2,0);
    }
    
    static int test1(int value1,int value2,int value3){
        int ans = value1 - value2 - value3;
        return ans;
    }
    
    
    public static void main(String[] args) {
       System.out.println(test1(12,5));
       System.out.println(test1(12,5));
       System.out.println(test1(12,5,2));
     
    }
    
}
