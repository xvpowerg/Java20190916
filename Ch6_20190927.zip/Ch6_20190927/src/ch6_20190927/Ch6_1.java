/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190927;
public class Ch6_1 {
    
    public static void main(String[] args) {
        //java 的封箱
        //只有基本型態有封箱
        /*byte   Byte
        short  Short
        int    Integer
        long  Long
        float Float
        double Double
        char  Character
        boolean Boolean
        */
        //手動封箱
        int base = 50;
       Integer boxing = Integer.valueOf(base);
       //手動解封箱         
       int unBoxing = boxing.intValue();
       System.out.println(unBoxing + 100);       
       //自動封箱
       Integer autoBoxing = 23;
       //自動解封箱 
       int autoUnboxing = autoBoxing;
       System.out.println("autoUnboxing:"+autoUnboxing);
       autoUnboxing = autoBoxing + 15;  
         System.out.println("autoUnboxing:"+autoUnboxing);  
        
    }
    
}
