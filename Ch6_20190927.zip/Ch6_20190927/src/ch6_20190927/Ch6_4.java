/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190927;

/**
 *
 * @author xvpow
 */
public class Ch6_4 {
    public static void main(String[] args) {
        //只要轉換的文字不是連續的"true"(不分大小寫) 就回傳false
        String isOpenStr ="true";
        boolean b1 = Boolean.parseBoolean(isOpenStr);
        System.out.println(b1);
        
       String isOpenStr2 ="tRuE";
        boolean b2 = Boolean.parseBoolean(isOpenStr2);  
          System.out.println(b2);
          
        String isOpenStr3 ="tR UE";
        boolean b3 = Boolean.parseBoolean(isOpenStr3);  
          System.out.println(b3);
          
          //10 轉 2
         String binary = Integer.toBinaryString(125);
         System.out.println(binary);
        //10 轉 8 
          String octal = Integer.toOctalString(125);
            System.out.println(octal);   
          //10 轉 16 
          String hex =   Integer.toHexString(125);
           System.out.println(hex);  
    }
    
}
