/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190927;

/**
 *
 * @author xvpow
 */
public class Ch6_6 {
   /* 1 找相同類型
      2 找同類型可相容的
      3 找其他同類型可相容的
      4 轉成封箱
    */
    static void test1(int v1){
        System.out.println("int");
    }
    static void test1(float v1){
        System.out.println("float");
    }
        static void test1(double v1){
        System.out.println("double");
    }
        
     static void test2(byte b1){
            System.out.println("byte");
      }
//        static void test2(long b1){
//            System.out.println("long");
//      }
     static void test2(float f1){
            System.out.println("float");
      }
    
     static void test3(Integer v1){
         System.out.println("Integer...");
     }
      static void test3(short v1){
         System.out.println("short...");
     }
      
      static void test4(Float f1){
          System.out.println("Float...");
      }
      static void test4(short v1){
          System.out.println("short...");
      }
      

    
    public static void main(String[] args) {
   
         /* test1(5);
          test1(5.0f);
          test1(5.0);*/
         /*test2(11);
         byte bx = 11;
          test2(bx);*/
         test3(25);
         
         //Float f1 = Integer.valueOf(25);
         //test4(25);
    }
    
}
