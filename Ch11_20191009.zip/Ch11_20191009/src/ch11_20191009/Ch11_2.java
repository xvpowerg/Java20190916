/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191009;

/**
 *
 * @author xvpow
 */
public class Ch11_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       TestClass t1 = new TestClass();
       TestClass t2 = new TestClass();
       //nonStatic 是獨享區 屬於物件 晚於類別
       t1.nonStaticValue = "Ken";
       t2.nonStaticValue = "Vivin";
       System.out.println("T1:"+t1.nonStaticValue);
       System.out.println("T2:"+t2.nonStaticValue);
       //static 是共享 屬於類別 早於物件
       //群聊
       t1.staticValue = "Join";
       t2.staticValue = "Iris";
       System.out.println("T1:"+t1.staticValue);
       System.out.println("T2:"+t2.staticValue);
       
       TestClass.staticValue = "Join";
       TestClass.staticValue = "Iris";
      // System.out.println(TestClass.staticValue);
      TestClass.testStaticMethod();
    }
    
}
