/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191009;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private int score;
    
    public Student(String name,int score){
        this.name = name;
        this.score = score;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setScore(int score){
        this.score = score;
    }
    public String toString(){
        return name+":"+score;
    }
    
   public boolean equals(Object obj){
       //obj == null 不用比
       //obj instanceof 指這個傳入的物件是一個Student嗎?
        //如果是就回傳true 不是回傳false
       if (obj == null || !(obj instanceof Student) ){
           return false;
       }
       
       Student tmSt = (Student)obj;
       
       return this.name.equals(tmSt.name) && this.score == tmSt.score;
   } 
    
}
