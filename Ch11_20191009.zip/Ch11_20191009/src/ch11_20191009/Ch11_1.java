/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191009;

/**
 *
 * @author xvpow
 */
public class Ch11_1 {

    public static void main(String[] args) {
       Student st1 = new Student("Ken",72);
       System.out.println(st1);
      Student st2 = new Student("Ken",72);  
      Student st3 = new Student("Vivin",95);  
      System.out.println(st1.equals(st2));
      System.out.println(st1.equals(st3));
      
    }
    
}
