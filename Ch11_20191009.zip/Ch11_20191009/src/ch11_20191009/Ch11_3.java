/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191009;

/**
 *
 * @author xvpow
 */
public class Ch11_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Item i1 = new Item();
        String value = i1.selectOption(0);
        System.out.println(value);
        value = i1.selectOption(5);
        System.out.println(value);
        //value = i1.selectOption(29);
       //當 index 小於 0 或大於 26
      // 時拋出 NotOptionException 這樣類型的錯誤拋出
      //此錯誤是非必要例外檢測的錯誤
        Item i2 = new Item("iPnone11");
        System.out.println(i2.selectOption(2));
     i2.printArray();
        
    }
    
}
