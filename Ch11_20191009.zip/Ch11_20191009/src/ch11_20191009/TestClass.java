/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191009;

/**
 *
 * @author xvpow
 */
public class TestClass {
    public String nonStaticValue = "TestClass nonStatic";
    public static String staticValue = "TestClass staticValue" ;        
   
    
    
    public static void testStaticMethod(){
        System.out.println(staticValue);
    }
}
