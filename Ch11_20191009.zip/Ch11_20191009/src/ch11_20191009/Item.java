/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191009;


public class Item {
    private String[] options = new String[26];
    private String name;
    //希望array [0] = 1 ...[1]=2 ..[9998] = 9999 [9999] = 10000
    public static int[] array = new int[10000];
    //初始化區塊 他會比建構子還來的早呼叫
    {        
        for (char c1 = 'A';c1 <= 'Z';c1++){
            String s = String.valueOf(c1);
            int index = (c1-'A');
            options[index] = s;            
        }        
               
    }
    
    static{
         for (int i =1;i<=10000;i++){
            array[i-1] = i;
        }
    }
    public static void printArray(){
        for (int v : array){
            System.out.println(v);
        }
    }
    
    
    public Item(){    
        
    }
    
    public Item(String name){      
        this.name = name;
    }
    

    
    public String selectOption(int number){
        if (number < 0 || number > 25){
            throw new NotOptionException();
        }
        return options[number];
    }
    
    
}
