
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch4_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int[] a4 = {5,3,8,9,11,25,6,1,13};   
     int[] copyArray =  Arrays.copyOf(a4, 6);
     for(int v : copyArray){
         System.out.print(v+" ");
     }
     System.out.println();
     int[] copyOfRangeArray = Arrays.copyOfRange(a4, 2, 6);//index >=2 index < 6
     for (int v2 : copyOfRangeArray){
          System.out.print(v2+" ");
     }
      System.out.println();
      
      /*
       陣列預設值:
       整數系為:0
       浮點數系:0.0
       字元:' '
       布林:false
       Other:null
      */
      int[] a5 = new int[100];
      System.out.println(a5[0]);
      Arrays.fill(a5, -1);
      System.out.println(a5[1]);   
      
      String[] names = new String[1000];
      Arrays.fill(names, "Empty");
      System.out.println(names[2]);
    }
    
}
