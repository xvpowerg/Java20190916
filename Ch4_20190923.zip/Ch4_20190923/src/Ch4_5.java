/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch4_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int[][] array1 = new int[2][3];
      int[] array2[] = new int[2][3];   
      int array3[][]  = new int[2][3];     
      int[][] array4[][][] = new int[2][3][4][5][6];  
      int[][] array5 = new int[2][];
      int[][] array6 = new int[][]{  {1,2,3},
                                     {4,5} 
                                   };
      int[][] array7 = {{8,9,11},
                        {3,2}};
      //java.lang.ArrayIndexOutOfBoundsException
      System.out.println(array7[2][1]);
      //java.lang.NullPointerException
       // array5[1][0]= 10;
      
      
    }
    
}
