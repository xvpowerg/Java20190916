/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Arrays;
public class Ch4_2 {

    public static void main(String[] args) {
        //小寫英文字母大於大寫英文字母
        //A最小Z最大
        //a最小z最大
        //由小到大
        //文字比大小
        //由左至右比 
        //如果字元都一樣 就看誰得文字比較長 就比較大
        String[] array1 = {"aBcd","Bacd","Cg","Cbdc","fff","ff"};
        Arrays.sort(array1);
        for (String msg : array1){
            System.out.print(msg+" ");
        }
          System.out.println("");          
     int index =  Arrays.binarySearch(array1, "z");
     System.out.println(index);
     int index2 =  Arrays.binarySearch(array1, "B");
      System.out.println(index2);
      int index3 =  Arrays.binarySearch(array1, "D");
       System.out.println(index3);    
    }
    
}
