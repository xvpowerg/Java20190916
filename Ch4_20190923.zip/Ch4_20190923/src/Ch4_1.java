/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Arrays;
public class Ch4_1 {

    public static void main(String[] args) {
        //宣告方式
        short[] s1 = new short[3];
        short s2[] = new short[3];
        //直接給初始化的方式 長度為3的陣列 [0]=1 [1]=2 [2] = 5
        short[] s3 = {1,2,5};
       //直接給初始化的方式 長度為4的陣列
        short[] a4 = new short[]{5,3,8,9};        
        s1 = new short[] {1,6,8};        
        System.out.println(s1[1]);
        //=============================
        int[] myArray = {25,6,8,11,17};
        //java排序預設都是由小到大 遞增排序ASC 
        System.out.println("排序前....");
        for (int v :myArray ){
            System.out.print(v+" ");
        }
         System.out.println();
          System.out.println("排序後....");
       Arrays.sort(myArray);
         for (int v :myArray ){
            System.out.print(v+" ");
        }
         System.out.println();  
        int index =  Arrays.binarySearch(myArray, 17);
        System.out.println(index);
        //定義x為被搜尋數
       //找到狀態回傳x所對應的陣列索引
       //找不到x 一律為負數

          //1 x數值比陣列的所有數值都小:一定回傳-1      
           int index2 =  Arrays.binarySearch(myArray, 2);
            System.out.println(index2);
          //2 x數值比陣列的所有數值都大:(陣列長度 +1) * -1
            int index3 =  Arrays.binarySearch(myArray, 83);
            System.out.println(index3);
          //3 x數值在陣列的數值之間:找到x位置的下一個元素的長度 * -1
            int index4 = Arrays.binarySearch(myArray, 21);
          System.out.println(index4);
          
       
        
    }
    
}
