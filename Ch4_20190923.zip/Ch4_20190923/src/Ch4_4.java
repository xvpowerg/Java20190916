/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch4_4 {

    public static void main(String[] args) {
     int[][] array2x3 = new int[2][3];
        array2x3[0][0] = 72;
        array2x3[0][1] = 35;
        array2x3[1][0] = 83;
        array2x3[1][2] = 54;
        for (int i =0;i<array2x3.length;i++){
             for (int c = 0;c < array2x3[i].length;c++){
                 System.out.printf("%2d ",array2x3[i][c]);
             } 
            System.out.println();
        }
          System.out.println();
        //72 35  0
        //83  0 54
        //foreach 形式的迴圈
        
        for (int[] a1 : array2x3 ){
            for (int a2 :a1){
                System.out.printf("%2d ",a2);
            }
            System.out.println();
        }
    }
    
}
