/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191002;

/**
 *
 * @author xvpow
 */
public class Person {
    private String name;
    private float height;
    private float weight;
    
    Person(){
        
    }
    Person(String name,float height,float weight){
        this.name = name;
        this.height = height;
        this.weight = weight;                
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    
    public float getHeight(){
        return this.height;
    }
    public void setHeight(float height){
        this.height = height;
    }
    
    public float getWeight(){
        return this.weight;
    }
    public void setWeight(float weight){
        this.weight = weight;
    }
    
    public void print(){
        System.out.println(name+":"+height+":"+weight);
    }
}
