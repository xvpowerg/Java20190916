/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191002;

/**
 *
 * @author xvpow
 */
public class Ch8_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Person p1 = new Person("Ken",173,62);
        p1.print();
        p1.setHeight(189);
        p1.print();
        System.out.println(p1.getWeight());
        Student st1 = new Student();
        st1.setName("Vivin");
        st1.setHeight(180);
        st1.setWeight(72);
        st1.print();
        Student st2 = new Student("Join",155,61);
        st2.print();
        Student st3 = new Student();
        //未填寫姓名 0.0 0.0
        st3.print();
        
    }
    
    
}
