/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191002;

/**
 *
 * @author xvpow
 */
public class Ch8_2 {

    //寫一個方法可以呼叫Teacher的print
    //寫一個方法可以呼叫Student的print
//    static void personPrint(Student st1){
//        st1.print();
//    }
//    static void personPrint(Teacher t1){
//        t1.print();
//    }
    //多型 Polymorphism
     static void personPrint(Person p){
         p.print();
     }
      //多型 可用在陣列或是vars這類型的應用
     static void personPrint(Person... ps){
         for (Person p1 : ps){
             p1.print();
         }
     }
    
    public static void main(String[] args) {
       Teacher t1 = new Teacher("Lnidy",
               161,50,"A0001");
       //t1.print();
       Student s1 = new Student("Gigi",
               152,45);      
       Teacher t2 = new Teacher("Ken",
               181,70,"B0003");
      Student s2 = new Student("Join",
               161,50);  
      personPrint(t1,s1,t2,s2);
      
     /* personPrint(t1);
      personPrint(s1);*/
      
    }
    
}
