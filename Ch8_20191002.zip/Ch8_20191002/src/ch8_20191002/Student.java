/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191002;

/**
 *
 * @author xvpow
 */
public class Student extends Person {
    //不會被繼承(Inheritance)的
    //1 建構子
    //2 私有的方法
    //3 私有的屬性
    //4 靜態的方法
    public Student(){   
        this("未填寫姓名",0,0);
    }
    public Student(String name,
        float height,float weight){        
        //super()可呼叫父類建構子
        //只能是建構子的第一條命令
       super(name,height,weight);
        /*this.setName(name);
        this.setHeight(height);
        this.setWeight(weight);*/        
    } 
    //複寫 Override
    public void print(){
        System.out.print("學生:");
        //super. 呼叫父類別的方法
        super.print();
//        System.out.println("學生:"+this.getName()+":"+
//                this.getHeight()+":"+this.getWeight());
    }
    
}
