/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191011;

/**
 *
 * @author xvpow
 */
public class Ch12_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
      //Shadow 遮蔽 
      //那些內容為遮蔽
      //1 所有屬性
      //2 所有靜態的 
      //遮蔽 看類別 複寫看物件
      TestShadow1 ts1 = new TestShadow2();
      ts1.staticValue = 72;
      ts1.testStaticShadow();
      
      //我在ts2加上staticValue 這時答案還是72 這就是Shadow
      TestShadow2 ts2 = new TestShadow2();
      ts2.staticValue = 65;
      ts2.testStaticShadow();
      
      
      
    }
    
}
