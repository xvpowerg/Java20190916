/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191011;

/**
 *
 * @author xvpow
 */
public class Ch12_3 {
    
    public static void main(String[] args) {
        TestShadow1 ts1 = new TestShadow2();
        ts1.nonStatiValue = 96;
        ts1.testNonStaticShadow();
        
        
    }
    
}
