/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191011;

/**
 *
 * @author xvpow
 */
public class Ch12_1 {
    
    public static void main(String[] args) {
       TestBlock  tb1 = new TestBlock();
       TestBlock  tb2 = new TestBlock();
       //每new 一次就會呼叫nonstatic的block
       //static的block 只會呼叫一次 他一定比 nonstatic 早呼叫        
    }
    
}
