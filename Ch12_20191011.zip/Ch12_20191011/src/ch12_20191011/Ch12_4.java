/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191011;

/**
 *
 * @author xvpow
 */
public class Ch12_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Student st1 = new Student("Ken",25);
       Student st2 = new Student("Ken",25);
       st2.appendScore(100);
       st2.appendScore(75);
       st2.appendScore(95);
       System.out.println(st2.equals(st1));
       
       System.out.println(st2);
    }
    
}
