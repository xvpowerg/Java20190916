/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191011;

/**
 *
 * @author xvpow
 */
public class Student {
    //一 學生 有 三個屬性
    //1 姓名 name 字串
    //2 年齡 age 整數
    //3 成績 給一個整數陣列長度為3
    private String name;
    private int age;
    private int[] scores = new int[3];
    private int index = -1;
    Student(String name,int age){
        this.name = name;
        this.age = age;
    }
    public void appendScore(int score){
        if (index < scores.length - 1 ){
            scores[++index] = score;
        }        
    }
    
    //instanceof

    //二 有一組建構子 可以傳入name age 來建立學生
    //寫一個appendScore(int score) 方法 , 會寫入score
    //只能寫入三次  不然會拋出 AppendScoreException
    
    //三 我希望 Student st1 = new Student("Ken",25);
    //  Student st2 = new Student("Ken",25);
    //st1.equals(st2) 會是true 條件式 姓名一樣 年齡一樣 就回傳true
        public boolean equals(Object obj){
        if (obj == null || !(obj instanceof Student) ){
            return false;
        }
        Student st1 = (Student)obj;
        return this.name.equals(st1.name) && this.age == st1.age;
    }
    //四 
    // Student st2 = new Student("Ken",25);
    // st2.appendScore(25);
    // st2.appendScore(60);
    // st2.appendScore(70);
    //System.out.println(st2) Ken:25:"成績:":25,60,70
      public String toString(){
          String msg = "";
          for (int s : scores){
              msg += s +",";
          }          
          return this.name+":"+this.age+"成績:"+msg;
      }
    
}
