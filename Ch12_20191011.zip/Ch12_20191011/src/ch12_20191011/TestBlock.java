/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191011;
public class TestBlock {
     {
       System.out.println("nonStatic 1"); 
    }
        
    TestBlock(){
        System.out.println("TestBlock()");
    }
   
    {
           System.out.println("nonStatic 2");  
    }
    
    static{
        System.out.println("Static 1");  
    }
    
      static{
        System.out.println("Static 2");  
    }
}
