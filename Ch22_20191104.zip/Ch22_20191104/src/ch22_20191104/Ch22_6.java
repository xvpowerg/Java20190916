/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191104;
import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
/**
 *
 * @author shihhaochiu
 */
public class Ch22_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Student>  list = new ArrayList<>();
        Student st1 = new Student("Ken",23);
        Student st2 = new Student("Vivin",12);
        Student st3 = new Student("Join",18);
        list.add(st1);
        list.add(st2);
        list.add(st3);
        
        //list.stream().map((st)->st.getAge()).forEach(System.out::println);
       int sum =  list.stream().mapToInt((st)->st.getAge()).sum();
       System.out.println(sum);
       
    DoubleSummaryStatistics ds = list.stream().mapToDouble((st)->st.getAge()).summaryStatistics();
    System.out.printf("Avg:%.2f %n",ds.getAverage());
    }
    
}
