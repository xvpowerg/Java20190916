/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191104;

import java.util.ArrayList;
import java.util.Optional;
/**
 *
 * @author shihhaochiu
 */
public class Ch22_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     ArrayList<String> list = new ArrayList<>();
        
        list.add("Vivin");
        list.add("Lindy");
        list.add("Ken");
        list.add("Joine");
        list.add("Ken");
        
        list.stream().distinct().forEach(System.out::println);
        System.out.println("===========");
        list.stream().filter((v)->v.length() > 3).forEach(System.out::println);
        System.out.println(list.size());
        Optional<String> opt1 =  list.stream().parallel().findAny();
        Optional<String> opt2 =  list.stream().findFirst();
        System.out.println(opt1.get());
        System.out.println(opt2.get());
    }
    
}
