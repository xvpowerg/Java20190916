/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191104;
import java.util.ArrayList;
import java.util.IntSummaryStatistics;
/**
 *
 * @author shihhaochiu
 */
public class Ch22_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Student st1 = new Student("Ken",10);
        
        st1.appendScore(75);
         st1.appendScore(83);
       Student st2 = new Student("Vivin",11);
       st2.appendScore(93);
        st2.appendScore(62);
       ArrayList<Student> list = new  ArrayList<>();
       list.add(st1);
       list.add(st2);
       //希望取得所有學生當中成績最高的分數
       //希望取得所有學生的平均分
      
       //用map 回傳 Stream<Stream<Integer>>
       
        //用 flatMap回傳 Stream<Integer> 展開另一個Stream
        IntSummaryStatistics is = 
                list.stream().flatMap(st->st.getScore()).
                        mapToInt(s->s).summaryStatistics();
  System.out.printf("Max%d Avg:%.2f%n",is.getMax(),is.getAverage());
   
    }
    
}
