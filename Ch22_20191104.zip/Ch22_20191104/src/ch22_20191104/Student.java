/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191104;
import java.util.Optional;
import java.util.ArrayList;
import java.util.stream.Stream;
/**
 *
 * @author shihhaochiu
 */
public class Student {
    
    private Optional<String> name = Optional.empty();
    private int age;
    private ArrayList<Integer> slist = new ArrayList<>();
    
    public Student(String name,int age){
        this.name = Optional.ofNullable(name);
        this.age = age;
    }
    public Stream<Integer> getScore(){
        return slist.stream();
    } 
    
    public void appendScore(int score){
        slist.add(score);
    }
    public Optional<String> getName(){
        return this.name;
    }
    
    public int getAge(){
        return age;
    }
}
