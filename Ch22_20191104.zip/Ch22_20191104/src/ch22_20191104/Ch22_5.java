/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191104;
import java.util.Optional;
import java.util.Random;
/**
 *
 * @author shihhaochiu
 */
public class Ch22_5 {
        
    
    static String genString(){
        Random ran = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i =1;i<=5;i++){
            sb.append(ran.nextInt(8000));
        }
        return sb.toString();
    }
    public static void main(String[] args) {
       
      Optional empty = Optional.empty();
     Optional<String> nameOption =  Optional.of("Vivin");
     Optional<String> ofNullable = Optional.ofNullable("Lindy");
     
        if (nameOption.isPresent()) {
            System.out.println(nameOption.get());
        }
     // Optional<String> nameOptionIsNull =  Optional.of(null);   
     
     //ofNullable 支持null
     //get() null會產生錯誤
        Optional<String> ofNullableIsNull =  Optional.ofNullable(null);   
         // System.out.println(ofNullableIsNull.get());
          
          
          String value1 = ofNullableIsNull.orElse("資料是null");
          System.out.println(value1);
          String value2 =  ofNullable.orElse("資料是null");
          System.out.println(value2);
          
         String orElseGet =  ofNullableIsNull.orElseGet(Ch22_5::genString);
         System.out.println(orElseGet);
         
         //如果內容為null拋出自定義錯誤
         ofNullableIsNull.orElseThrow(IllegalArgumentException::new);
          
    }
    
}
