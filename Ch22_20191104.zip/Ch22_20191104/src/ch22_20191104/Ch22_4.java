/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191104;

/**
 *
 * @author shihhaochiu
 */
public class Ch22_4 {

    private static void verifyName(String name){
        String msg = 
            name.length() >0 && name.length() < 10?"正確的姓名":"錯誤的姓名";
        System.out.println(msg);
    }
    public static void main(String[] args) {
        Student st1 = new Student("Ken",10);
        st1.getName().ifPresent(Ch22_4::verifyName); 
        String msg = st1.getName().orElse("姓名不可為null");
        System.out.println(msg);
//        if (st1.getName().length() > 0 && st1.getName().length() < 10){
//            System.out.println("正確的姓名");
//        }
    }
    
}
