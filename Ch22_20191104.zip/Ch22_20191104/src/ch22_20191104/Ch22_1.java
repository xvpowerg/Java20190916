/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191104;
import java.util.ArrayList;
import java.util.stream.Stream;
/**
 *
 * @author shihhaochiu
 */
public class Ch22_1 {
    
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("Ken");
        list.add("Vivin");
        list.add("Lindy");
        list.add("Joine");
        //stream 特點
        // 1 Stream 有分惰性layz 或 終端 Terminal
        //2 Stream 不會改變自己
        //3 一個Stream物件不能重複使用
        
        //惰性layz
        list.stream().peek((v)->System.out.println(v));
        //終端 Terminal
       long count =  list.stream().peek(System.out::println).count();
        System.out.println("count:"+count);
        
        //一個Stream物件不能重複使用
        Stream st1 =  list.stream();
        long c2 = st1.count();
        System.out.println(st1.findFirst());
        
        
    }
    
}
