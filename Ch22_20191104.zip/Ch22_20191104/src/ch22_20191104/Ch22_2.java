/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191104;

import java.util.ArrayList;

/**
 *
 * @author shihhaochiu
 */
public class Ch22_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        
        list.add("Vivin");
        list.add("Lindy");
        list.add("Ken");
        list.add("Joine");
        list.add("Ken");
        //allMatch 所有元素要符合 回傳true
       boolean allMatch=  list.stream().allMatch((s)->s.length() > 2);
       boolean anyMatch=  list.stream().anyMatch((s)->s.length() > 4);
       System.out.println(allMatch);
       System.out.println(anyMatch); 
       
      boolean noneMatch =  list.stream().noneMatch((s)->s.length() < 1);
       System.out.println(noneMatch); 
       //allMatch 只要碰到不符合的元素就中斷
         boolean allMatch2 =list.stream().peek((v)->System.out.println(v)).allMatch((s)->s.length() > 3);
         System.out.println(allMatch2); 
           System.out.println("=========="); 
         //anyMatch 只要碰到符合的元素就中斷
       boolean anyMatch2 = list.stream().peek((v)->System.out.println(v)).anyMatch((s)->s.length() < 4);
       System.out.println(anyMatch2); 
        System.out.println("=========="); 
         boolean noneMatch2 = list.stream().peek((v)->System.out.println(v)).noneMatch((s)->s.length() < 4);
       System.out.println(noneMatch2);    
    }
    
}
