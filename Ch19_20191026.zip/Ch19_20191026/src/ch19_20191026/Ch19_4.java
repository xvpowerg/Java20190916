/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191026;
import java.util.TreeSet;
import java.util.Comparator;
/**
 *
 * @author xvpow
 */
public class Ch19_4 {

   static class MyComparator implements Comparator<Item>{
       public int compare(Item i1,Item i2){
           if (i1.getId() == i2.getId()){
               return 0;
           }else if(i1.getId()  > i2.getId()){
               return 1;
           }
            return -1;
       }
   }
    public static void main(String[] args) {
        MyComparator comp = new MyComparator();
       TreeSet<Item> set = new TreeSet<>(comp);
       Item i1 = new Item(10,"Item1");
       Item i2 = new Item(8,"Item2");
       Item i3 = new Item(6,"Item3");
       Item i4 = new Item(7,"Item4");
       Item i5 = new Item(6,"Item5");
       
       set.add(i1);
       set.add(i2);
       set.add(i3);
       set.add(i4);
       set.add(i5); 
       
       set.stream().forEach(System.out::println);
       
    }
    
}
