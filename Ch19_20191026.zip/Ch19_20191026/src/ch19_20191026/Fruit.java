/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191026;

/**
 *
 * @author xvpow
 */
public class Fruit implements Comparable<Fruit> {
    public enum Color{
        RED,
        PURPLE,
        YELLOW        
    }
    
    private Color color;
    private int price;
    private String name;
    
    public Fruit(String name,int price,Color color){
        this.name = name;
        this.price = price;
        this.color = color;
    }
    
    /*
    如果兩物件相等回傳0
    如果兩物件目前小於傳入的回傳小於0的數值
    如果兩物件目前大於傳入的回傳大於0的數值
    */
    public int compareTo(Fruit f1){
       if (this.getPrice() ==  f1.getPrice() ){
           return this.getName().compareTo(f1.getName());
       }else if(this.getPrice()  >f1.getPrice()){
           return 1;
       }
       return -1;
    }
    
    public String getName(){
        return name;
    }
    
    public Color getColor(){
        return color;
    }
    
      public int getPrice(){
        return price;
    }  
      
  public boolean equals(Object obj){
            System.out.println("equals Name:"+this.getName());
      if (obj == null || obj instanceof Fruit == false){
         return false;
      }
      Fruit tmp = (Fruit)obj;
      
      return this.getName().equals(tmp.getName()) && 
              this.getColor().equals(tmp.getColor()) &&
              this.getPrice() == tmp.getPrice();
      
  }
      
  public String toString(){
      return this.getName()+":"+this.getPrice()+":"+this.getColor();
  }    
  //若p則q  equalse 一樣 hashCode也要一樣 
  //在HashSet中 先判斷hashCode 在判斷 equals
  public int hashCode(){
      System.out.println("hashCode Name:"+this.getName());
      return this.getName().hashCode() + this.getPrice()+this.getColor().hashCode();
  }
      
}
