/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191026;
import java.util.TreeSet;
public class Ch19_3 {

    public static void main(String[] args) {
        TreeSet<Fruit> set = new TreeSet();
        Fruit fr1 = new Fruit("Apple",50,Fruit.Color.RED);
        Fruit fr2 = new Fruit("Banana",20,Fruit.Color.YELLOW);
        Fruit fr3 = new Fruit("Grape",60,Fruit.Color.PURPLE);
         Fruit fr4 = new Fruit("Apple",60,Fruit.Color.YELLOW);
        set.add(fr1);
        set.add(fr2);
        set.add(fr3);
         set.add(fr4);
        for (Fruit f :set){
            System.out.println(f);
        }
    }
    
}
