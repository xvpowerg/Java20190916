/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191026;
import java.util.HashSet;
import java.util.Iterator;
public class Ch19_1 {
    public static void main(String[] args) {
//      HashSet<String> set = new HashSet<>();
//      set.add("Ken");
//      set.add("Vivin");
//      set.add("Lindy");
//      set.add("Lindy");
//      set.add("Join");
//     Iterator<String> it = set.iterator();
//     while(it.hasNext()){
//         System.out.println(it.next());
//     }

    HashSet<Fruit> set2 = new HashSet<>();
    //String name,int price,Color color
    Fruit fr1 = new Fruit("Apple",50,Fruit.Color.RED);
    Fruit fr2 = new Fruit("Banana",20,Fruit.Color.YELLOW);
    Fruit fr3 = new Fruit("Grape",60,Fruit.Color.PURPLE);
    Fruit fr4 = new Fruit("Apple",50,Fruit.Color.RED);
    System.out.println(fr1.equals(fr4));
     set2.add(fr1);
     set2.add(fr2);
     set2.add(fr3);
     set2.add(fr4);
     
     for (Fruit f : set2){
         System.out.println(f);
     }
     
    }
    
}
