package ch19_20191026;
import java.util.SortedSet;
import java.util.TreeSet;
public class Ch19_2 {
    public static void main(String[] args) {
       TreeSet<Integer> treeSet = new TreeSet<>();
       treeSet.add(71);
       treeSet.add(30);
       treeSet.add(50);
       treeSet.add(20);
       
       for (int v : treeSet){
           System.out.println(v);
       }
       
       System.out.println("min:"+treeSet.first());
       System.out.println("max:"+treeSet.last());
       int n = 29;
       System.out.println("ceiling:"+treeSet.ceiling(n)); //>= n
       System.out.println("higher:"+treeSet.higher(n));//> n
        int n2 = 30;
       System.out.println("ceiling2 :"+treeSet.ceiling(n2)); //>= n2
       System.out.println("higher2:"+treeSet.higher(n2));//> n2
      int n3 = 29; 
     System.out.println("floor:"+treeSet.floor(n3));//<= n3
     System.out.println("lower:"+treeSet.lower(n3));//<n3
      int n4 = 30; 
     System.out.println("floor2:"+treeSet.floor(n4));//<= n4
     System.out.println("lower2:"+treeSet.lower(n4));//<n4  
     System.out.println("==========================");//<n4   
    SortedSet<Integer> subSet = treeSet.subSet(20, 60);
    for (int v : subSet){
        System.out.println(v);
    }
    }
    
}

