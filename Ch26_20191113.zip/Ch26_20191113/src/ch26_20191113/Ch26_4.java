/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20191113;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
/**
 *
 * @author shihhaochiu
 */
public class Ch26_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String url = "jdbc:derby://localhost:1527/MyStudent";
        String user = "qwer";
        String password = "qwer";
        
        try(Connection con = DriverManager.getConnection(url,user,password);
                Statement stm = con.createStatement();){
           ResultSet rest = stm.executeQuery("SELECT * FROM studentinfo");
           while(rest.next()){
               System.out.printf("%s: %.2f,%.2f,%.2f %n",rest.getString(2),
                       rest.getFloat(3),rest.getFloat(4),rest.getFloat(5));
           }
        }catch(SQLException ex){
            System.out.println(ex);
        }
        
    }
    
}
