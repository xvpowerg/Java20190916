/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20191113;

/**
 *
 * @author shihhaochiu
 */
public class Ch26_1 {

    static class Test1{
        private int i;
        public synchronized void add(){
            
            for (int k = 1;k<=10;k++){
                i++;
                System.out.println(i);
            }
            
        }
       public synchronized void add2(){
            System.out.println("Thread Name 1:"+Thread.currentThread().getName());
            for (int k = 1;k<=10;k++){
                i++;
                System.out.println(i);
            }
            System.out.println("Thread Name 2:"+Thread.currentThread().getName());
            
        }
       
          public  void add3(){
            System.out.println("Thread Name 1:"+Thread.currentThread().getName());
            synchronized(this){
                for (int k = 1;k<=10;k++){
                i++;
                System.out.println(i);
                }
            }
            
            System.out.println("Thread Name 2:"+Thread.currentThread().getName());
            
        }
        
    }
    
    
    public static void main(String[] args) {
           Test1 t1= new Test1();
        
              Thread th1 = new Thread(()->{
          t1.add3();
      });
      Thread th2 = new Thread(()->{
          t1.add3();
      });
       th1.start();
       th2.start();
        
//        Test1 t1= new Test1();
//        
//              Thread th1 = new Thread(()->{
//          t1.add2();
//      });
//      Thread th2 = new Thread(()->{
//          t1.add2();
//      });
//       th1.start();
//       th2.start();
  
//      Thread th1 = new Thread(()->{
//          t1.add();
//      });
//      Thread th2 = new Thread(()->{
//          t1.add();
//      });
//      
//      th1.start();
//      th2.start();
        
        
    }
    
}
