/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20191113;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
public class Ch26_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String url = "jdbc:derby://localhost:1527/MyStudent";
        String user = "qwer";
        String password = "qwer";
        try(  Connection conn = DriverManager.getConnection(url, user, password); 
              Statement stm = conn.createStatement()){
          int count =  stm.executeUpdate("INSERT INTO "
                   + " studentinfo(id,stname,score1,score2,score3) "
                  + "VALUES(200,'Vivin',75.6,89.1,98.7)");
          System.out.println(count);
          
        }catch(SQLException ex){
            System.out.println(ex);
        }
      
           
        
        
        
    }
    
}
