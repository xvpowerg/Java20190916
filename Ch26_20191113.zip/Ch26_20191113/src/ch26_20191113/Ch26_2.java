/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20191113;

/**
 *
 * @author shihhaochiu
 */
public class Ch26_2 {

   
    static class Test1{
        public synchronized void m1(Test1 local){
            System.out.println(Thread.currentThread().getName());
            local.m2();
        }
        public synchronized void m2(){
            System.out.println(Thread.currentThread().getName()+":m2...");
        }
    }
    public static void main(String[] args) {
       Test1 t1 = new Test1();
       Test1 t2 = new Test1(); 
       
       Thread th1 = new Thread(){
           public void run(){
                t1.m1(t2);
           }
       };
       Thread th2 = new Thread(){
           public void run(){
                 t2.m1(t1);
           }
       };
      
      th1.start();
      th2.start();
        
    }
    
}
