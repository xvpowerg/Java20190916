/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch3_2 {

 
    public static void main(String[] args) {
       String name = null;    
       switch(name){
           case "Vivin":
               System.out.println(85);
               break;
           case "Lindy":
               System.out.println(72);
               break;
           case "Ken":
               System.out.println(93);
               break;
           default:
               System.out.println("錯誤姓名");
              break;
       } 
       
        
    }
    
}
