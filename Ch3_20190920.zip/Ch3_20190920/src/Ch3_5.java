/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch3_5 {

    public static void main(String[] args) {
        //arry不是基本型態    
        int[] array1 = new int[5];
        array1[0] = 1;
        array1[1] = 75;
        array1[2] = 93;
        array1[3] = 185;
        array1[4] = 725;
        //使用FOR
        for (int i = 0; i < array1.length; i++){
             System.out.print(array1[i]+" ");
        }
        System.out.println("======================");
       //Foreach 迴圈
       for (int v : array1){
           System.out.print(v+" ");
       }
        System.out.println("======================");
       
        java.util.Arrays.stream(array1).forEach(System.out::println);
        
        
    }
    
}
