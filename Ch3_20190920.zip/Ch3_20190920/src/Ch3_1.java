/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch3_1 {

    public static void main(String[] args) {
      /* int kmhr = 120;
       
       if (kmhr < 62){
            System.out.println("無此分類"); 
       } else if (kmhr >= 62 && kmhr <= 117){
           System.out.println("輕度颱風!");
       }else if(kmhr >= 118 && kmhr <= 183){
            System.out.println("中度颱風!");
       }else{
             System.out.println("強烈颱風");
       }*/
      
      System.out.println("1 跑");
      System.out.println("2 走");
      System.out.println("3 跳");
      java.util.Scanner scann = new java.util.Scanner(System.in);
      int action = scann.nextInt();
      //switch 可傳入的參數類型有
      //byte short int char String emun
//      switch(action){
//          case 1:
//             System.out.println("跑");  
//              break;
//          case 2:
//              System.out.println("走");  
//              break;
//          case 3:
//              System.out.println("跳");
//              break;
//      }
    final int RUN = 1;
    final int WALK = 2;
    final int JUMP = 3;
    //放在case後的變數必須是常數(final的變數)  
   switch(action){
          case RUN:
             System.out.println("跑");  
              break;
          default:
              System.out.println("錯誤");
          case WALK:
              System.out.println("走");  
              break;
          case JUMP:
              System.out.println("跳");
              break;          
      }
       
    }
    
}
