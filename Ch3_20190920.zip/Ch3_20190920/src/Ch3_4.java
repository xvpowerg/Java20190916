/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch3_4 {
    public static void main(String[] args) {
        //break 跳離
        //continue 繼續下一次
        
//        for (int i =1;i<=5;i++){
//            //if (i == 3) break;
//            if (i == 3) continue;
//            System.out.println(i);
//        }
          
         System.out.println("T1");
         Tage1:
         for (int k =1; k<=3;k++){             
            System.out.println("T2_"+k); 
             Tage2:
             for (int g = 2; g<=5; g++){
                 //if (g==4) break Tage1;
                 if (g==4) continue Tage1;
                 System.out.println("T3_"+g); 
                 System.out.printf("%d*%d=%d ",k,g,k*g);
             }
             System.out.println("=============");
             
                System.out.println("E3_"+k); 
         }
          System.out.println("E1");    
        
        
    }    
}
