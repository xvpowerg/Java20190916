/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch3_3 {
    static int step1(){
        System.out.println("Step1");
        return 1;
    }    
     static boolean step2(){
        System.out.println("Step2");
        return true;
    }
      static void step3(){
        System.out.println("Body Step3");   
    }
     static void step4(){
        System.out.println("Step4");   
    }
    public static void main(String[] args) {   
        //for
//        for (int i =1  ; i<=10 ; i++  ){
//            System.out.println(i);
//        }
           
//        for (int k =1,y = step1();k<=3&&step2();k++,step4()){
//              step3();
//        }

        //while 當不清楚數量時可使用while
//            int c = 5;            
//            while(c >= 0){
//                System.out.println(c--);
//            }
            
        //do while
        int k =1;
        do{
            System.out.println(k);
            k += 2;
        }while(k <= 10);
        
        
        
    }
    
}
