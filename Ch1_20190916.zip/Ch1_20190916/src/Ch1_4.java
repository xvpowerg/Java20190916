/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_4 {
    public static void main(String[] args){
        int count = 0;
        count = count + 1;
        
        count = count + 1;
        //先顯示+1前的數值 在顯示加1後的數值
        System.out.println("加一前的數值:"+count);
        count = count +1;
        System.out.println("加一後的數值:"+count);
        
        //顯示+1後的數值
        count = count + 1;
        System.out.println("加一後的數值:"+count);
        
        
        int value1 = count;
        System.out.println(value1);
        count = count +1;
        System.out.println(count);
        
        count  = count +1;
        value1 = count;
        System.out.println(value1);
        System.out.println(count);
         System.out.println("===================");
         
        int step =0;
        int value2 = step++;
        System.out.println(value2);
         System.out.println(step);
         value2 =  ++step;
          System.out.println(value2);
         System.out.println(step);  
        
        
        
    }
}
