/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_1 {
    public static void main(String[] args){
        System.out.println("Howard");
        //變數
        //基本型態Primitive
        int value = 10;        
        //非基本型(參考 reference)
        String name = "Ken";
        
        //Primitive
        //整數
           //byte 8bit -128~127
           //short 16bit -32768~+32767
           //int 32bit -2147483648~+2147483647 default
           //long 64bit
        //浮點數 多了小數點 IEEE754
           //float 32bit 跟int很像
           //double 64bit 跟long很像 default
        byte b1 = 10;
        int i2 = 30;
        //大倒小有問題
        //b1 = i2;        
        float pi = 3.1415f;
        System.out.println(pi);
        //字元 16bit 0~65535 沒有負數
        //Character        
        char c1 = 'B';
        char c2 = 67;
        System.out.println(c1);
        System.out.println(c2);
        char c3 = '\u0035';//16進位表達式
        System.out.println(c3);
        
        //boolean 布林
        boolean isRun = false;
        boolean canJump = true;
        System.out.println(isRun);
       System.out.println(canJump);
       
       //變數命名歸規則
       // 開頭可以是英文字母 或 _ 或 $
       // 第二個單字可以是英文字母 或 _ 或 $ 或 數字
       int value1 = 10;
       
    }
}
