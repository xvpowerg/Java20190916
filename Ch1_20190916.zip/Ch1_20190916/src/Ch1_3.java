/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_3 {
    public static void main(String[] args){
        //優先子
        //()
        // ++ -- + -
        // * / %
        //+ -
        //> = < <= >= 
        //&&  || 
        //?:
        
        int v1 = 10;
        int v2 = 20;
        //+ 對於字串 有串接都變為字串的能力
        System.out.println(v1+"+"+v2+"=" +(v1+v2));
        //f =>format %d 整數 %f 浮點數 %b 布林 %s 字串 %n 段行
        System.out.printf("%d-%d=%d%n",v1,v2,v1-v2);
        System.out.printf("%d*%d=%d%n",v1,v2,v1*v2);
        //整數除法取商數
        System.out.printf("%d/%d=%d%n",v1,v2,v1/v2);
        //浮點數的除法 就是真的計算
        float v3 = 20;
        System.out.printf("%d/%.2f=%.2f%n",v1,v3,v1/v3);
        // 印出 % %%
        int v4 = 8,v5 = 6;
        System.out.printf("%d%%%d=%d%n",v4,v5,v4%v5);  
    }
}
