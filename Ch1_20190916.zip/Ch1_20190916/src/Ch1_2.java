/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_2 {
    public static void main(String[] args){
        System.out.println("Test!");
        //2進位0b表示2進位
        int value1 = 0b1101;        
        System.out.println(value1);
        //8 進位
        int value2 = 015;
        System.out.println(value2);
        //16進位
        //A=10 B=11 C=12 D=13 E=14 F =15
        int value3 = 0xF5;
        System.out.println(value3);
        
        int value4 = 10_000_000;
        System.out.println(value4);
        //底線口絕 底線前後必須是底線或數字
        int value5 = 10___0____0;
        
        int value6 = 0b010__10;
        System.out.println(value6);
        int value7 = 0xF_F_11___AA;
        System.out.println(value7);
        int value8 = 0__1_73;
        System.out.println(value8);
         
        float valur9 = 2.718__281__828f;
        int value10 = 10__0__0__0;
        int value11 = 10000;
        System.out.println(value10 == value11);
    }
}
