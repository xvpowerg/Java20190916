/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch2_1 {
    public static void main(String[] args){
        //愛考
//            int x= 1;
//            System.out.println(++x);//2
//            System.out.println(x++);//2
//            System.out.println("=====================");            
//            System.out.println(--x);//2            
//            System.out.println(x--);//2
//            System.out.println(x);
            int y = 1;
            int h = 5 + ++y + 2 - y++ - --y;            
            System.out.println(h);
            System.out.println(y);
              System.out.println("====================");
            int score = 0;
            //score = score + 20;
            score +=  20;
            System.out.println(score);
            //score = score + 10;
            score +=  10;
            System.out.println(score);
            score = score - 5;
              score -=  5;
            System.out.println(score);            
            //float f1 = score - 1.2f;
           // System.out.println(f1);  
            score -= 1.2f;
           System.out.println(score);            
            
    }
}
