/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch2_5 {
    public static void main(String[] args) {
     
        //if　如果(boolean)
        //如果｛｝只有一段命令時可不加{}
        int age = 21;
        if (age >= 18){
            System.out.println("成年！");
            System.out.println("好棒棒！");
        }
           if (age >= 18)System.out.println("成年！");
           
         System.out.println("好棒棒！");
       //if else
           //如果｛｝只有一段命令時可不加{}
           //else ｛｝只有一段命令時可不加{}
         int score = 60;
         if (score >= 60){
             System.out.println("及格");
         }else{
             System.out.println("不及格");
         }
          if (score >= 60) 
              System.out.println("及格");
          else 
              System.out.println("不及格");
         
         
       //if else if else
       
       //switch case 超愛考
        
        
    }
    
}
