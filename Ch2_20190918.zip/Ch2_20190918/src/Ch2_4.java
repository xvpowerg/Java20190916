/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch2_4 {

    public static void main(String[] args) {
       int value1 = 20;
       int value2 = 51;
       System.out.println(value1 > value2);
       System.out.println(value1 < value2);
       System.out.println(value1 >= value2);
       System.out.println(value1 <= value2); 
       System.out.println(value1 == value2);
       System.out.println(value1 != value2); 
        System.out.println("===================="); 
        //非基本型態比較相等時不要用==
        //非基本型態比較相等時要使用equals
       String name1 = "Ken";
       String name2 = "Vivin";
       System.out.println(name1 == name2);
       System.out.println(name1 != name2);
         System.out.println("===================="); 
       String name3 = "Ken";
       String name4 = "Ken";
       System.out.println(name3 == name4);
       System.out.println(name3 != name4);
         System.out.println("===================="); 
       String name5 = new String("Ken");
       String name6 = "Ken";
       System.out.println(name5 == name6);
       System.out.println(name5 != name6);   
       System.out.println(name5.equals(name6)); 
       //字串池
       
    }
    
}
