/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch2_3 {
    public static void main(String[] args) {
            //& | ^
   int v1 = 0b10011;//19   
   System.out.println(v1);
   int v2 = 0b11100; // 28
    System.out.println(v2);
    
    System.out.println(v1 & v2);    
    System.out.println(v1 | v2);   
    
    int pKye = v1 ^ v2;
    System.out.println(v1 ^ v2); 
    System.out.println(v1 ^ pKye);
    System.out.println(v2 ^ pKye);
    
    }
    
}
