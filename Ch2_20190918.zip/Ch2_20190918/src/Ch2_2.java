/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch2_2 {
    public static void main(String[] args) {
      boolean b1 = false;
      boolean b2 = true;
      //且　兩邊為真才為真　&&
      //或　單邊為真就是真 ||
      //反向　唱反調 !
      //互斥　一真一假才為真 ^
      
      System.out.println(b1 && b2);
      System.out.println(b1 || b2);
      System.out.println(!b1);
      System.out.println(b1 ^ b2);
      System.out.println("==============");
      //短路現象
      boolean b3 = true;
      boolean b4 = false;
      int k1 = 0;
      int k2 = 0;
      //且 &&　如果左邊為false就不判斷右邊
      System.out.println(b4 && ++k1 >0 );
      System.out.println(k1);
     System.out.println(b3 && ++k1 >0 );
      System.out.println(k1);
      //或 ||　如果左邊為true就不判斷右邊
      System.out.println(b4 || ++k2 >0 );
      System.out.println(k2);
     System.out.println(b3 || ++k2 >0 );
      System.out.println(k2);
      
      
    }
    
}
