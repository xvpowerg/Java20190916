/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191016;
public class Ch14_1 {

    static void testFly(Fly fly,float speed){
  
        if (speed > Fly.MAX_SPEED ){
            System.out.println("錯誤的速度!");
           return;
        }        
        fly.flying(speed);
    }
    static void tesRun(Run run,float speed){
        run.runing(speed);
    }
    public static void main(String[] args) {
       
     IronMan im = new IronMan();
        im.flying(100);
        im.walking(25);
        im.runing(60);
       testFly(im,120); 
       tesRun(im,50); 
       
       IronManAttack1 ima1 = new IronManAttack1();
       ima1.attacking(100, 2);
      testFly(im,1200000);   
    }
    
}
