/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191016;

public interface Ray {
    float RAY_POWER_MAX = 500;
   float shooting(float power);   
   default public boolean testRayPower(float power){
      if (shooting(power) > RAY_POWER_MAX) {
          System.out.println("錯誤的power");
          return false;
      }
      return true;
   }
   
   static int max(int pow1,int pow2){
       return pow1 > pow2 ?pow1:pow2;
   }
}
