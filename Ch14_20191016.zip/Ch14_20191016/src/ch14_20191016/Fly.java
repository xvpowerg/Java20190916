package ch14_20191016;
public interface Fly {
    //預設如下
    //public static final float MAX_SPEED= 10000;
    float MAX_SPEED = 10000;
    void flying(float speed);
}
