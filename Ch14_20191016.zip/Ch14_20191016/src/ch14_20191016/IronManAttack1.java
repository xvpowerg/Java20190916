/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191016;

/**
 *
 * @author xvpow
 */
public class IronManAttack1  extends IronMan implements Attack,IronManAttackGroup{
    public void attacking(int power,int select){
       switch(select){
           case 1:
             System.out.println("shooting:"+ shooting(power));
               break;
           case 2:
             System.out.println("hit:"+ hit(power));  
               break;
       }
        System.out.println(select+":"+power);
    }
    
    public float shooting(float power){
            power += 50;
        return power;
    }
    public float hit(float power){
        power += 20;
        return power;
    }
}
