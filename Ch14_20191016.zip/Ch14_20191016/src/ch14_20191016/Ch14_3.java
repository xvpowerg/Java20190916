/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191016;

/**
 *
 * @author xvpow
 */
public class Ch14_3 implements Test4 {
    public static void main(String[] args) {
         Ch14_3 c143 = new Ch14_3();
        c143.t1();    
    }
    
}
