/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191016;

/**
 *
 * @author xvpow
 */
public interface Physical {
    float hit(float power);
}
