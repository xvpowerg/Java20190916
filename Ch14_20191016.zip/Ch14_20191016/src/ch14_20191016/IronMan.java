/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191016;

/**
 *
 * @author xvpow
 */
public  class IronMan implements Run,Walk,Fly {
    public void runing(float speed){
        System.out.println("IronMan runing speed:"+speed);
    }
    public void walking(float speed){
         System.out.println("IronMan walking speed:"+speed);
    }
    public void flying(float speed){
           System.out.println("IronMan flying speed:"+speed);
    }
}
