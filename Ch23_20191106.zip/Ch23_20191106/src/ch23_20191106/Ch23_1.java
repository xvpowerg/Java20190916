/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191106;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.Map;

/**
 *
 * @author shihhaochiu
 */
public class Ch23_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         ArrayList<Student>  list = new ArrayList<>();
        Student st1 = new Student("Ken",23);
        Student st2 = new Student("Vivin",12);
        Student st3 = new Student("Join",18);
        Student st4 = new Student("Lindy",12);
        Student st5 = new Student("Tom",26);
        Student st6 = new Student("Ben",31);
        Student st7 = new Student("Lucy",18);
        list.add(st1);
        list.add(st2);
        list.add(st3);
        list.add(st4);
        list.add(st5);
        list.add(st6);
        list.add(st7);
        
//        list.stream().filter((st)->
//                st.getAge() > 18).
//                forEach(System.out::println);

// List<Student> newList =   list.stream().filter((st)->
//                st.getAge() > 18).
//        collect(Collectors.toList());
// newList.forEach(System.out::println);

//ArrayList newlist2 = list.stream().filter((st)->
//                st.getAge() > 18).collect(Collectors.toCollection(ArrayList::new));
//newlist2.forEach(System.out::println);

//Map<Integer,String> mpa = 
//        list.stream().
//                collect(Collectors.toMap((stv)->stv.getAge(), 
//                        (stv)->stv.getName().get(),
//                        (v1,v2)->v1+","+v2));
//       System.out.println(mpa);
// Map<Integer,List<Student>>  group =
//         list.stream().collect(Collectors.groupingBy(st->st.getAge()));
//System.out.println(group);
 String names = list.stream().map(st->st.getName().get()).
         collect(Collectors.joining(",", "name:", "."));
System.out.println(names);
    }
    
}
