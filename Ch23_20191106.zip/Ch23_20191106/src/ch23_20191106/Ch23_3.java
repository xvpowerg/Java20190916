/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191106;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
/**
 *
 * @author shihhaochiu
 */
public class Ch23_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         File srcFile = new  File("/Users/shihhaochiu/Documents/javadir/java-test.zip");
      File targetSrc = new File("/Users/shihhaochiu/Documents/javadir/java-test_copy.zip");
      //System.out.println(srcFile.exists());
      try{
          FileInputStream fileIn = new FileInputStream(srcFile);
          FileOutputStream fileOut = new FileOutputStream(targetSrc);
          BufferedInputStream bfIn = new BufferedInputStream(fileIn);
          BufferedOutputStream bfOut = new BufferedOutputStream(fileOut);
           int data = -1; 
          while( (data = bfIn.read()) !=-1 ){
             
              bfOut.write(data);
        }
          bfOut.close();
          bfIn.close();
      }catch(FileNotFoundException ex){
          System.out.println(ex);
      }catch(IOException ex){
          System.out.println(ex);
      }
    }
    
}
